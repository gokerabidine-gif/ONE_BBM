# ONE BBM Android APK build

The repository includes a GitHub Actions workflow at `.github/workflows/android-apk.yml`.

## Build an installable APK

1. Push this complete source tree to the repository's `main` branch (or upload it as the repository source).
2. Open **Actions → Build ONE BBM Android APK → Run workflow**.
3. Wait for the `build-apk` job to finish successfully.
4. Download the workflow artifact named **ONE-BBM-debug-APK**. It contains `app-debug.apk`.

The workflow installs Node.js and Java, provisions the Android SDK, installs the locked npm dependencies, runs the project's `npm run gate` checks, builds the web game, generates the Capacitor Android project, enforces landscape orientation, syncs Capacitor, and runs `assembleDebug`.

A local APK is not considered complete until `android/app/build/outputs/apk/debug/app-debug.apk` exists and is non-empty. A successful JavaScript/web build alone is not an Android APK.

## Local build prerequisites

- Node.js 22
- Java 21
- Android SDK with the platform/build-tools required by the Capacitor Android plugin
- Network access to npm and Android/Gradle dependency repositories

Then run:

```bash
npm ci
npm run gate
npm run build
npx cap add android
npx cap sync android
cd android && ./gradlew assembleDebug
```
