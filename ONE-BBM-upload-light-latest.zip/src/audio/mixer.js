/**
 * AUDIO / MIXER
 *
 * The signal path, top down:
 *
 *   voices ──► bus (weapons | foley | ambience | voice | ui)
 *                │           each bus: trim ──► bus compressor
 *                ▼
 *   ┌── worldSum ─► muffleLP ─► muffleGain ──┐        (deafening / concussion)
 *   │      ▲                                 │
 *   │   reverb returns                       ▼
 *   │      ▲                              masterSum ─► masterComp ─► softClip ─► out
 *   │   convolver x5 (space blend)           ▲
 *   │      ▲                                 │
 *   └── reverbSend ◄─ bus.send ◄─ per-voice ui bus + tinnitus (bypass the muffle,
 *                     send. The per-bus node so HUD and the ring stay audible)
 *                     is POST-FADER, so a bus's
 *                     volume/mute takes its wet tail with it.
 *
 * Ducking is a manual sidechain: gunfire pushes `ambience`/`foley` down with a
 * fast setTargetAtTime and lets them float back over ~400 ms. That is exactly
 * what a real game mix does, and it is far more predictable than trying to make
 * a DynamicsCompressor listen to another bus.
 */

import { biquad, gain, limiterCurve, shaper, clamp, osc } from './dsp.js';
import { IR_SPECS, generateIR } from './ir.js';

/**
 * `exterior: true` means the bus is heard THROUGH the car body when the player
 * is inside one, so it is summed into the cabin filter rather than straight
 * into the world. The player's own engine, the radio and dialogue are inside
 * the cabin with them and get their own colouring instead.
 */
const BUS_DEFS = {
  weapons:  { trim: 0.95, exterior: true, comp: { threshold: -7, knee: 8, ratio: 2.6, attack: 0.003, release: 0.16 } },
  foley:    { trim: 0.9, exterior: true, comp: { threshold: -14, knee: 10, ratio: 2.0, attack: 0.004, release: 0.2 } },
  ambience: { trim: 0.5, exterior: true, comp: { threshold: -24, knee: 12, ratio: 2.0, attack: 0.05, release: 0.5 } },
  // A pursuit is heard for minutes at a time, which is a different job from a
  // gunshot: -2.8 dB off the shipped 0.8, because the thing the owner reported
  // about the sirens was that they dominated. `sirens.js` shares this level
  // across every unit sounding, so the cap holds however many cruisers arrive.
  sirens:   { trim: 0.58, exterior: true, comp: { threshold: -16, knee: 10, ratio: 2.4, attack: 0.01, release: 0.3 } },
  // The engine bus carries a lot of sustained low end; it is compressed harder
  // than anything else so a redline pass does not swallow the rest of the mix.
  vehicles: { trim: 0.72, exterior: false, comp: { threshold: -18, knee: 10, ratio: 3.2, attack: 0.02, release: 0.28 } },
  music:    { trim: 0.62, exterior: false, comp: { threshold: -15, knee: 12, ratio: 2.6, attack: 0.012, release: 0.3 } },
  // Dialogue and barks. 0.85 shipped and the owner's report on it was "louder
  // and more prominent than before ... distracting": a story line ducks the
  // whole bed 12.4 dB and then sat 8.2 dB on top of the hole it had made. This
  // is the bus half of the fix (-2.3 dB); `LINE_TRIM` in vox.js is the other
  // half, and duckprobe measures the resulting margin over the ducked bed.
  voice:    { trim: 0.65, exterior: false, comp: { threshold: -18, knee: 8, ratio: 3.0, attack: 0.006, release: 0.22 } },
  ui:       { trim: 1.6, exterior: false, comp: null },
};

export class Mixer {
  /**
   * @param {BaseAudioContext} actx
   * @param {import('../core/rng.js').Rng} rng
   */
  constructor(actx, rng, opts = {}) {
    this.actx = actx;
    this.rng = rng;
    // Headroom matters more than loudness: at 0.62 a single gunshot peaks near
    // -3 dBFS and the limiter is only reached by dense combat, so the mix keeps
    // its dynamic range instead of being flattened.
    this.masterVolume = opts.masterVolume ?? 0.95;

    /* ---- master chain (built first, everything hangs off it) ------ */
    this.masterSum = gain(actx, 1);
    // Headroom stage. It sits BEFORE the compressor/clipper on purpose: a
    // post-limiter volume control only scales an already-squashed signal, and
    // that is what destroys the difference between a footstep and a gunshot.
    //
    // 0.32 is measured, not chosen: the `mixstress` bench scene — a redlining
    // V8 in the cabin, the radio, six traffic vehicles, three sirens, rain,
    // automatic fire and an explosion — peaks at about -2 dBFS here, so the
    // loudest thing the game can produce still leaves 2 dB before the limiter
    // has to do anything, and a footstep at -50 dBFS is still 50 dB of range
    // below it.
    this.preGain = gain(actx, 0.32);
    this.masterComp = actx.createDynamicsCompressor();
    // Safety net only: a single gunshot should barely touch it, a firefight
    // plus a grenade should be held together by it.
    this.masterComp.threshold.value = -2;
    this.masterComp.knee.value = 3;
    this.masterComp.ratio.value = 4;
    this.masterComp.attack.value = 0.0035;
    this.masterComp.release.value = 0.14;
    this.softClip = shaper(actx, limiterCurve(), '4x');
    this.masterGain = gain(actx, this.masterVolume);

    this.masterSum.connect(this.preGain);
    this.preGain.connect(this.masterComp);
    this.masterComp.connect(this.softClip);
    this.softClip.connect(this.masterGain);
    this.masterGain.connect(actx.destination);

    /* ---- concussion / deafening path ----------------------------- */
    // Everything diegetic runs through this so a nearby explosion can muffle
    // the whole world without touching the HUD or the tinnitus tone.
    this.worldSum = gain(actx, 1);
    this.muffleLP = biquad(actx, 'lowpass', 20000, 0.5);
    this.muffleHS = biquad(actx, 'highshelf', 3500, 0.7, 0);
    this.muffleGain = gain(actx, 1);
    this.worldSum.connect(this.muffleLP);
    this.muffleLP.connect(this.muffleHS);
    this.muffleHS.connect(this.muffleGain);
    this.muffleGain.connect(this.masterSum);

    /* ---- the cabin ------------------------------------------------- */
    // Sitting in a car is the single biggest EQ move in an open-world mix: the
    // street goes away, the glass rolls off everything above ~1 kHz and the
    // body panels take 12 dB out of the top. `setCabin(1)` is windows up.
    this.exteriorSum = gain(actx, 1);
    this.cabinLP = biquad(actx, 'lowpass', 20000, 0.6);
    this.cabinHS = biquad(actx, 'highshelf', 2200, 0.7, 0);
    this.cabinGain = gain(actx, 1);
    this.exteriorSum.connect(this.cabinLP);
    this.cabinLP.connect(this.cabinHS);
    this.cabinHS.connect(this.cabinGain);
    this.cabinGain.connect(this.worldSum);
    this.cabin = 0;

    /* ---- buses ---------------------------------------------------- */
    this.buses = {};
    for (const name in BUS_DEFS) {
      const def = BUS_DEFS[name];
      const input = gain(actx, 1);        // voices connect here
      const duck = gain(actx, 1);         // sidechain victim
      const trim = gain(actx, def.trim);  // static balance
      // Post-fader reverb send scaler. Every source's per-voice send routes
      // through its bus's `send` node (see `busSend`) on the way to the shared
      // reverb, so the same volume/mute control that scales the dry bus scales
      // its wet tail too. Default 1 => the tuned mix is byte-identical until a
      // slider moves; `setBusVolume` drives it. Without this the reverb send is
      // pre-fader and a source (a siren especially, whose send is 0.5) stays
      // audible with its bus turned all the way down.
      const send = gain(actx, 1);
      input.connect(duck);
      duck.connect(trim);
      let tail = trim;
      let comp = null;
      if (def.comp) {
        comp = actx.createDynamicsCompressor();
        comp.threshold.value = def.comp.threshold;
        comp.knee.value = def.comp.knee;
        comp.ratio.value = def.comp.ratio;
        comp.attack.value = def.comp.attack;
        comp.release.value = def.comp.release;
        trim.connect(comp);
        tail = comp;
      }
      // ui bypasses the muffle: menu clicks must survive a grenade.
      tail.connect(name === 'ui' ? this.masterSum
        : def.exterior ? this.exteriorSum : this.worldSum);
      this.buses[name] = { input, duck, trim, send, comp, baseTrim: def.trim, duckAmount: 0 };
    }

    /* ---- reverb ---------------------------------------------------- */
    // One send bus fanning into five convolvers; the space probe crossfades
    // between them. Sharing the send keeps the cost fixed no matter how many
    // voices are alive.
    this.reverbSend = gain(actx, 1);
    // Pre-send shaping: no sub into the convolvers (muddy) and no fizz above
    // 9 kHz (real rooms do not reflect that back at you from 30 m away).
    this.sendHP = biquad(actx, 'highpass', 170, 0.7);
    this.sendLP = biquad(actx, 'lowpass', 9000, 0.7);
    this.reverbSend.connect(this.sendHP);
    this.sendHP.connect(this.sendLP);
    // Each bus's post-fader send tap feeds the shared reverb through this point.
    for (const name in this.buses) this.buses[name].send.connect(this.reverbSend);

    this.spaces = {};
    this.spaceNames = Object.keys(IR_SPECS);
    this.reverbReturn = gain(actx, 0.9);
    this.reverbReturn.connect(this.worldSum);
    this._irReady = false;

    this.spaceWeights = { tight: 0, room: 0, street: 0.35, tunnel: 0, open: 0.65 };

    /* ---- tinnitus (built on demand, torn down when silent) -------- */
    this._tin = null;
    this.deafness = 0; // 0..1, public: UI/render may read this

  }

  /**
   * Render the impulse responses. Split out from the constructor because it is
   * the single most expensive thing this subsystem does (~15 ms for all five)
   * and we only want to pay it once audio is actually going to be heard.
   */
  buildReverbs() {
    if (this._irReady) return;
    const actx = this.actx;
    for (const name of this.spaceNames) {
      const conv = actx.createConvolver();
      conv.normalize = false;
      try {
        conv.buffer = generateIR(actx, this.rng.fork(), IR_SPECS[name]);
      } catch (err) {
        console.warn('[audio] IR generation failed for', name, err);
        continue;
      }
      const g = gain(actx, this.spaceWeights[name] ?? 0);
      const live = (this.spaceWeights[name] ?? 0) > 0.012;
      if (live) this.sendLP.connect(conv);
      conv.connect(g);
      g.connect(this.reverbReturn);
      this.spaces[name] = { conv, gain: g, live };
    }
    this._irReady = true;
  }

  /**
   * Blend weights from the space probe. Ramped so doorways do not click.
   *
   * Convolvers whose weight has fallen to nothing are unplugged from the send:
   * a 2.8 s stereo convolution is the most expensive node in the graph and
   * there is no reason to compute three of them into a zero gain. Typically two
   * of the five are live at any moment.
   */
  setSpace(weights, smooth = 0.35) {
    const t = this.actx.currentTime;
    for (const name of this.spaceNames) {
      const w = clamp(weights[name] ?? 0, 0, 1);
      this.spaceWeights[name] = w;
      const s = this.spaces[name];
      if (!s) continue;
      s.gain.gain.setTargetAtTime(w, t, smooth);
      const want = w > 0.012;
      if (want === s.live) continue;
      if (want) {
        this.sendLP.connect(s.conv);
      } else {
        // Its gain is already ~0, so cutting the input is inaudible.
        try { this.sendLP.disconnect(s.conv); } catch { /* not connected */ }
      }
      s.live = want;
    }
  }

  /** Bus input node a voice should connect to. */
  bus(name) {
    return (this.buses[name] ?? this.buses.foley).input;
  }

  /**
   * Post-fader reverb send node for a bus. A voice hands its per-voice send gain
   * here instead of straight to `reverbSend`, so the bus's volume/mute control
   * scales its wet tail as well as its dry signal. Falls back to the foley bus,
   * matching `bus()`.
   */
  busSend(name) {
    return (this.buses[name] ?? this.buses.foley).send;
  }

  /**
   * How enclosed the listener is by a vehicle body. 0 = on foot, 1 = sealed
   * cabin. Ramped over ~0.25 s so a door closing is a move, not a switch.
   */
  setCabin(amount, smooth = 0.25) {
    const a = clamp(amount, 0, 1);
    this.cabin = a;
    const t = this.actx.currentTime;
    this.cabinLP.frequency.setTargetAtTime(20000 * Math.pow(0.055, a), t, smooth);
    this.cabinHS.gain.setTargetAtTime(-15 * a, t, smooth);
    this.cabinGain.gain.setTargetAtTime(1 - 0.42 * a, t, smooth);
  }

  /** Duck one named bus. Used for radio-under-siren and radio-under-dialogue. */
  duckBus(name, amount, hold = 0.2) {
    const b = this.buses[name];
    if (!b) return;
    const a = clamp(amount, 0, 0.95);
    if (a <= b.duckAmount + 0.01) return;
    const t = this.actx.currentTime;
    b.duckAmount = a;
    b.duckHold = hold;
    b.duck.gain.cancelScheduledValues(t);
    b.duck.gain.setTargetAtTime(1 - a, t, 0.03);
  }

  /**
   * Sidechain duck. `amount` 0..1 of gain reduction, `hold` seconds before it
   * starts floating back. Called on every gunshot and explosion.
   */
  duck(amount, hold = 0.12) {
    const t = this.actx.currentTime;
    const apply = (name, scale) => {
      const b = this.buses[name];
      if (!b) return;
      const a = clamp(amount * scale, 0, 0.92);
      if (a <= b.duckAmount + 0.01) return; // an existing deeper duck wins
      b.duckAmount = a;
      b.duckHold = hold;
      b.duck.gain.cancelScheduledValues(t);
      b.duck.gain.setTargetAtTime(1 - a, t, 0.012);
    };
    apply('ambience', 1);
    apply('foley', 0.55);
    apply('music', 0.75);
    apply('voice', 0.4);
    apply('vehicles', 0.3);
  }

  /**
   * Temporary hearing damage. `level` 0..1. Muffles the world, dips its level
   * and starts a tinnitus tone that outlives the muffling.
   */
  concuss(level) {
    level = clamp(level, 0, 1);
    if (level <= this.deafness) return;
    this.deafness = level;
    const t = this.actx.currentTime;
    const cutoff = 20000 * Math.pow(0.024, level); // 1.0 -> ~480 Hz
    this.muffleLP.frequency.cancelScheduledValues(t);
    this.muffleLP.frequency.setTargetAtTime(clamp(cutoff, 320, 20000), t, 0.02);
    this.muffleHS.gain.setTargetAtTime(-22 * level, t, 0.02);
    this.muffleGain.gain.setTargetAtTime(1 - 0.55 * level, t, 0.02);
    this._startTinnitus(level);
  }

  _startTinnitus(level) {
    const actx = this.actx;
    const t = actx.currentTime;
    if (this._tin) {
      // Re-trigger: just push the envelope back up.
      this._tin.g.gain.cancelScheduledValues(t);
      this._tin.g.gain.setTargetAtTime(0.05 * level, t, 0.03);
      this._tin.until = t + 4 + 7 * level;
      return;
    }
    const g = gain(actx, 0);
    // Two close tones plus a third an octave up: a single sine reads as a test
    // tone, three beating partials read as ringing ears.
    const o1 = osc(actx, 'sine', 3980);
    const o2 = osc(actx, 'sine', 4130);
    const o3 = osc(actx, 'sine', 7420);
    const g1 = gain(actx, 0.6), g2 = gain(actx, 0.45), g3 = gain(actx, 0.18);
    o1.connect(g1); o2.connect(g2); o3.connect(g3);
    g1.connect(g); g2.connect(g); g3.connect(g);
    // Slow wobble so it never sounds like a stuck oscillator.
    const lfo = osc(actx, 'sine', 0.23);
    const lfoG = gain(actx, 26);
    lfo.connect(lfoG);
    lfoG.connect(o2.frequency);
    g.connect(this.masterSum); // post-muffle on purpose
    o1.start(t); o2.start(t); o3.start(t); lfo.start(t);
    g.gain.setTargetAtTime(0.05 * level, t, 0.03);
    this._tin = { g, nodes: [o1, o2, o3, lfo, g1, g2, g3, lfoG], until: t + 4 + 7 * level };
  }

  /** Per-frame housekeeping: duck recovery, deafening recovery, tinnitus teardown. */
  update(dt) {
    const t = this.actx.currentTime;

    for (const name in this.buses) {
      const b = this.buses[name];
      if (b.duckAmount <= 0) continue;
      if (b.duckHold > 0) {
        b.duckHold -= dt;
        continue;
      }
      b.duckAmount = Math.max(0, b.duckAmount - dt * 2.6);
      b.duck.gain.setTargetAtTime(1 - b.duckAmount, t, 0.09);
      if (b.duckAmount < 0.01) {
        b.duckAmount = 0;
        b.duck.gain.setTargetAtTime(1, t, 0.09);
      }
    }

    if (this.deafness > 0) {
      // Recovery is slow at first then quick — matches how temporary threshold
      // shift actually behaves, and it feels dramatic.
      this.deafness = Math.max(0, this.deafness - dt * (0.1 + this.deafness * 0.22));
      const cutoff = 20000 * Math.pow(0.024, this.deafness);
      this.muffleLP.frequency.setTargetAtTime(clamp(cutoff, 320, 20000), t, 0.25);
      this.muffleHS.gain.setTargetAtTime(-22 * this.deafness, t, 0.25);
      this.muffleGain.gain.setTargetAtTime(1 - 0.55 * this.deafness, t, 0.25);
    }

    if (this._tin) {
      if (t > this._tin.until - 3.5) this._tin.g.gain.setTargetAtTime(0, t, 1.1);
      if (t > this._tin.until) {
        for (const n of this._tin.nodes) {
          try { n.stop?.(t); } catch { /* already stopped */ }
          n.disconnect();
        }
        this._tin.g.disconnect();
        this._tin = null;
      }
    }
  }

  setMasterVolume(v) {
    this.masterVolume = clamp(v, 0, 1);
    this.masterGain.gain.setTargetAtTime(this.masterVolume, this.actx.currentTime, 0.03);
  }

  setBusVolume(name, v) {
    const b = this.buses[name];
    if (!b) return;
    const f = clamp(v, 0, 2);
    const t = this.actx.currentTime;
    b.trim.gain.setTargetAtTime(f * b.baseTrim, t, 0.05);
    // Post-fader: the same factor scales this bus's send into the shared reverb,
    // so the wet tail follows the fader. `f` is the raw slider factor (1 at
    // default), not `f * baseTrim` — the send already carries the tuned wet
    // level, and we only want the player's control on top of it.
    b.send.gain.setTargetAtTime(f, t, 0.05);
  }

  /** Rough gain-reduction readout, handy for the debug overlay. */
  get reduction() {
    return this.masterComp.reduction ?? 0;
  }

  dispose() {
    if (this._tin) {
      for (const n of this._tin.nodes) {
        try { n.stop?.(); } catch { /* noop */ }
        n.disconnect();
      }
      this._tin.g.disconnect();
      this._tin = null;
    }
    for (const name in this.spaces) {
      this.spaces[name].conv.disconnect();
      this.spaces[name].conv.buffer = null;
      this.spaces[name].gain.disconnect();
    }
    this.spaces = {};
    for (const name in this.buses) {
      const b = this.buses[name];
      b.input.disconnect(); b.duck.disconnect(); b.trim.disconnect();
      b.send.disconnect(); b.comp?.disconnect();
    }
    this.reverbSend.disconnect(); this.sendHP.disconnect(); this.sendLP.disconnect();
    this.reverbReturn.disconnect();
    this.exteriorSum.disconnect(); this.cabinLP.disconnect(); this.cabinHS.disconnect();
    this.cabinGain.disconnect();
    this.worldSum.disconnect(); this.muffleLP.disconnect(); this.muffleHS.disconnect();
    this.muffleGain.disconnect();
    this.masterSum.disconnect(); this.preGain.disconnect(); this.masterComp.disconnect();
    this.softClip.disconnect(); this.masterGain.disconnect();
  }
}
