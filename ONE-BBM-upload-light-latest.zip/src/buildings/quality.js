/** Quality-aware facade detail distance, bounded by active world budgets. */
export function farFacadeDetailDistance(quality, q = {}) {
  const base = quality === 'ultra' ? 700 : 520;
  const streamLimit = Number.isFinite(q.streamRadius) ? q.streamRadius : base;
  const drawLimit = Number.isFinite(q.drawDistance) ? q.drawDistance : base;
  return Math.min(base, streamLimit, drawLimit);
}

/**
 * Per-building LOD compensation. Keeps facade bands readable slightly
 * farther away without increasing the streamed city radius.
 */
export function facadeLodScale(quality) {
  // cull.js divides the LOD threshold by this value. Values below
  // one therefore keep high-detail facade bands visible farther away.
  if (quality === 'ultra') return 1 / 1.16;
  if (quality === 'high') return 1 / 1.12;
  if (quality === 'medium') return 1 / 1.08;
  return 1 / 1.03;
}
