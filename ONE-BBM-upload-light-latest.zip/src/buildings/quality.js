/** Quality-aware facade detail distance, bounded by active world budgets. */
export function farFacadeDetailDistance(quality, q = {}) {
  const base = quality === 'ultra' ? 700 : 520;
  const streamLimit = Number.isFinite(q.streamRadius) ? q.streamRadius : base;
  const drawLimit = Number.isFinite(q.drawDistance) ? q.drawDistance : base;
  return Math.min(base, streamLimit, drawLimit);
}
