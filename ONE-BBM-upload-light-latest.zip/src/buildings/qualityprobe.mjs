import assert from 'node:assert/strict';
import { farFacadeDetailDistance, facadeLodScale } from './quality.js';
assert.equal(farFacadeDetailDistance('ultra', {streamRadius:1000,drawDistance:6000}),700);
assert.equal(farFacadeDetailDistance('high', {streamRadius:440,drawDistance:2200}),440);
assert.equal(farFacadeDetailDistance('ultra', {streamRadius:500,drawDistance:6000}),500);
assert.equal(farFacadeDetailDistance('ultra', {streamRadius:1000,drawDistance:600}),600);
assert.equal(farFacadeDetailDistance('medium', {}),520);
console.log('building quality probe: 5 assertions passed');

assert.ok(Math.abs(facadeLodScale('low') * 1.03 - 1) < 1e-10);
assert.ok(Math.abs(facadeLodScale('medium') * 1.08 - 1) < 1e-10);
assert.ok(Math.abs(facadeLodScale('high') * 1.12 - 1) < 1e-10);
assert.ok(Math.abs(facadeLodScale('ultra') * 1.16 - 1) < 1e-10);
assert.ok(facadeLodScale('ultra') < facadeLodScale('low'));
console.log('facade LOD direction probe: 5 assertions passed');
