import assert from 'node:assert/strict';
import { farFacadeDetailDistance, facadeLodScale } from './quality.js';
assert.equal(farFacadeDetailDistance('ultra', {streamRadius:1000,drawDistance:6000}),700);
assert.equal(farFacadeDetailDistance('high', {streamRadius:440,drawDistance:2200}),440);
assert.equal(farFacadeDetailDistance('ultra', {streamRadius:500,drawDistance:6000}),500);
assert.equal(farFacadeDetailDistance('ultra', {streamRadius:1000,drawDistance:600}),600);
assert.equal(farFacadeDetailDistance('medium', {}),520);
console.log('building quality probe: 5 assertions passed');

assert.equal(facadeLodScale('low'), 1.03);
assert.equal(facadeLodScale('medium'), 1.08);
assert.equal(facadeLodScale('high'), 1.12);
assert.equal(facadeLodScale('ultra'), 1.16);
console.log('facade LOD scale probe: 4 assertions passed');
