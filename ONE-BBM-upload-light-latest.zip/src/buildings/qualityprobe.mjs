import assert from 'node:assert/strict';
import { farFacadeDetailDistance } from './quality.js';
assert.equal(farFacadeDetailDistance('ultra', {streamRadius:1000,drawDistance:6000}),700);
assert.equal(farFacadeDetailDistance('high', {streamRadius:440,drawDistance:2200}),440);
assert.equal(farFacadeDetailDistance('ultra', {streamRadius:500,drawDistance:6000}),500);
assert.equal(farFacadeDetailDistance('ultra', {streamRadius:1000,drawDistance:600}),600);
assert.equal(farFacadeDetailDistance('medium', {}),520);
console.log('building quality probe: 5 assertions passed');
