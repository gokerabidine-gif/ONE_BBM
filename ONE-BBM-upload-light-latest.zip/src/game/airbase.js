/**
 * GAME — RIDGELINE AFB: the restricted-zone ASSAULT encounter.
 *
 * A FREE-ROAM ENCOUNTER, not a story chapter. `world.airbase` publishes the
 * fence polygon, gates, patrol loop, apron parking and `insidePerimeter` —
 * this module consumes that API (never re-deriving a spatial fact, per the
 * one-fact-one-owner rule) and makes the base defend itself:
 *
 *   - CROSSING THE PERIMETER arms the encounter: a klaxon (the existing
 *     positioned siren one-shot, re-fired on a loop), a HUD warning
 *     ("RESTRICTED AREA — LETHAL FORCE AUTHORIZED"), and a 'trespass' crime
 *     reported through the EXISTING heat vocabulary. Trespass is priced by
 *     `police`'s own tune table (3.0 heat — under a first star on its own)
 *     rather than this module asserting a star count: the garrison, not the
 *     city police, is the threat inside the wire, and the police price the
 *     crime the way they price every other one. Kills the player scores
 *     against guards then escalate stars exactly like any other body
 *     (`actor:death` is already priced).
 *
 *   - GUARDS: waves of RANGED hostiles from the published patrol waypoints
 *     and gate posts, via the existing hostile pool (`peds.spawnHostile` —
 *     real Peds with capsules, collision and ragdolls). Rifle-class stand-off:
 *     range 54 m, the hostile brain's own tracer + damage path. Capped at
 *     GUARD_CAP alive so the fight is intense but never a wall of bodies,
 *     reinforced in small waves while the player stays inside.
 *
 *   - TANK EMPLACEMENTS: the parked Bulwarks seeded on the published apron
 *     slots become live emplacements — `v.aimTurret(point)` slews the EMITTED
 *     turret at spec rates (it keeps tracking while the hull sleeps, by
 *     design), and `v.fireShell()` lobs the 105 m/s shell every 4-6 s when
 *     range and line of sight permit. The shell is slow and loud — dodgeable
 *     on foot — and detonates through the canonical 'explosion' event.
 *     HOLD-FIRE RULE: while the jet chase is live the tanks track but do not
 *     fire — the interceptors own an airborne (or boarded) target, and a
 *     105 m/s shell against a jet is wasted fire-control. It also means the
 *     stolen jet is not deleted on the apron before the chase can happen.
 *
 *   - PATROL JEEPS: the existing 'suv' class in a one-off matte olive-drab —
 *     a paint override on spawn, the same trivial-variant path `boss.js`
 *     already uses — that drive at the player while the base is armed, using
 *     the shared `driveToward` (the same physics-respecting steering every
 *     mission driver and the provisional pursuit use). No new vehicle class.
 *
 *   - WIND-DOWN: leaving the perimeter starts a cooldown; keeping line of
 *     sight from the garrison slows it, breaking it (or getting far away)
 *     runs it at full rate. On stand-down the guards are despawned through
 *     the hostile pool, the turrets stop tracking and the jeeps stop.
 *     Everything also winds down on player death / respawn / save adoption
 *     via `reset()` (wired in `game/index.js` beside `hostiles.clear()`).
 *
 *   - STEAL A JET: boarding any 'jet' inside the perimeter (the canonical
 *     'vehicle:enter' event) flags the theft and scrambles two pursuit jets —
 *     see `jetchase.js`.
 *
 * ───────────────────────────────────────────────────────────────────────────
 * A MACHINE ONLY OPERATES WITH SOMEBODY IN IT
 * ───────────────────────────────────────────────────────────────────────────
 * REPORTED, from play: "exiting a tank the tank starts shooting at you right
 * away". It did, and this file was the cause. `_emplacements` skipped a tank
 * only when it WAS the car the player is sitting in — a test of OWNERSHIP, not
 * of occupancy — so the frame the player stepped out, the gun he had just been
 * firing became an emplacement again and laid itself on him. `_patrol` had the
 * same shape: the jeeps were spawned with nobody in them at all and drove
 * anyway, so a stolen jeep left at the fence went back to chasing him.
 *
 * The garrison's machines are therefore CREWED, explicitly: `_seed` seats a
 * crew record on every emplacement and every patrol jeep (`v.aiCrew`, the
 * field `vehicles/tank.js` reads), and both loops skip anything `_crewed`
 * says is empty — no aim, no shell, no throttle. Boarding one takes its crew
 * out for good (`_onEnter`), so a machine the player has stolen is DEAD the
 * moment he steps out of it and stays that way; nothing in this file ever puts
 * a crew back. Killing a crew is the same door, and the same result.
 *
 * The invariant is ALSO enforced one level down, in `fireShell` itself, so a
 * future caller cannot re-open it — see the crew-gate note in `tank.js`.
 * `debugArmAbandoned` restores the pre-fix arming path on a live build; that
 * is the negative control `airbaseprobe` runs, and `milprobe` runs the
 * firing-site half node-only.
 *
 * NEGATIVE-CONTROL HATCH: `?noassault=1` / `OW_NO_ASSAULT=1` leaves the base
 * dressed (parked jets, tanks, jeeps) but inert — nothing arms, nothing
 * chases. Same shape as `?noairbase=1`, under which `world.airbase.pad` is
 * null and this module does nothing at all.
 *
 * ARCHITECTURE.md: rule 2 (subsystems via `wq`/`ctx.peek`, the airbase via
 * the published `world.airbase` object), rule 4 (forked rng), rule 5 (all
 * scratch preallocated; the arm/disarm edges may allocate, frames may not).
 * The pause contract: this module reads NO input; while paused `dt` is 0 and
 * every timer holds, and 'vehicle:enter' cannot fire behind a menu.
 */

import * as THREE from 'three';
import { wrapAngle, dist, dist2, driveToward, clamp01 } from './util.js';
import { JetChase } from './jetchase.js';

/** Concurrent armed guards. HOSTILE_MAX is 24 pool-wide; 8 leaves the story
 *  chapters their share even if one is somehow live at the same time. This is
 *  the LATE-fight ceiling — the concurrent cap RAMPS from GUARD_CAP0 so the
 *  first wave is a firefight, not a firing squad (see `_guardCap`). */
const GUARD_CAP = 8;
/** Concurrent guards the instant the base arms, and the seconds of engagement
 *  it takes to reach the full GUARD_CAP. Fewer guns focused at once early. */
const GUARD_CAP0 = 3;
const GUARD_CAP_RAMP = 30;
/** Guards per reinforcement wave, and seconds between waves. */
const WAVE_SIZE = 3;
const WAVE_PERIOD = 7;
/** Rifle-class stand-off guard. `range` is the hostile brain's fire range.
 *  `dmg` was 8 (measured ~15-20 DPS across the first wave, lethal in ~6.5 s
 *  with no accuracy/miss model in the shared hostile brain — every shot lands).
 *  5 keeps a wave threatening while leaving the player a fighting chance to
 *  break for a jet; lingering under the full ramp is still lethal. */
const GUARD_OPTS = {
  hp: 90, dmg: 5, ranged: true, range: 54, speed: 3.4, tag: 'airbase', leash: 140,
};
/** Guard spawn annulus around the player, m — in sight, not in his face. */
const SPAWN_MIN = 28;
const SPAWN_MAX = 185;

/** Emplacements armed / jets parked / jeeps on patrol. */
const TANK_N = 3;
const JET_N = 3;
const JEEP_N = 2;
/** Main-gun envelope, m, and the cadence between shells (reload is 4 s). */
const TANK_RANGE = 230;
const TANK_MIN = 22;
const FIRE_PERIOD = 4.2;
const FIRE_JITTER = 1.8;
/** Fire only once the emitted turret bears within this, rad. */
const AIM_TOL = 0.06;

/* ---- THE SPIN-UP, so the base does not open with instant lethal fire ---- */
/** Seconds after the wire is crossed before the guns are fully lethal. The
 *  klaxon sounds and the HUD warns immediately (the base is REACTING), guards
 *  are still mustering and the turrets slew onto you — but the first wave holds
 *  its fire and the main guns hold their shells until the base has "spun up".
 *  A driven-in car gets these seconds to move before anything is thrown at it. */
const GRACE_SPINUP = 3.5;
/** RANGING IN. A 2100-point shell one-shots any car it lands on, so the
 *  emplacements walk their fire onto a fresh target rather than dropping the
 *  first round on its roof: the aim point starts BRACKET_MAX metres off and
 *  closes to dead-on over BRACKET_RAMP seconds. Past the shell's damage reach
 *  (radius x1.2 = 9 m) an off-target round only SHOVES the car — loud, close,
 *  survivable — instead of wrecking it. Lingering lets the bracket collapse. */
const BRACKET_MAX = 15;
const BRACKET_RAMP = 13;
/** Fewer guns at once: no two emplacements may loose a shell inside this
 *  window, so a stolen or driven-in car never eats three simultaneous rounds. */
const FIRE_STAGGER = 2.4;

/** Seconds outside the wire before the base stands down. */
const OUT_COOLDOWN = 12;
/** Beyond this far from the fence the cooldown runs full rate regardless. */
const FAR_DIST = 220;
/** Klaxon re-fire and HUD warning cadence, s. */
const ALARM_PERIOD = 6.5;
const WARN_PERIOD = 24;

/** Matte olive drab for the patrol Overlooks — a paint override, not a class. */
const JEEP_PAINT = 0x39412e;

export function assaultDisabled() {
  try {
    if (typeof location !== 'undefined' &&
      new URLSearchParams(location.search).get('noassault') === '1') return true;
  } catch { /* no location */ }
  try {
    if (typeof process !== 'undefined' && process?.env?.OW_NO_ASSAULT === '1') return true;
  } catch { /* no process */ }
  return false;
}

/**
 * NEGATIVE-CONTROL HATCH for the survivability tuning. `?assaulthard=1` /
 * `OW_ASSAULT_HARD=1` reverts the playability work — no spin-up grace, no
 * fire bracketing, no shell stagger, full guard damage, the whole garrison
 * concurrent from the first frame — so `airbaseprobe` can prove the tuned
 * arm actually keeps the player alive by watching the reverted arm kill him
 * fast. It does NOT change the vehicle specs or the encounter's structure;
 * it only flips the difficulty knobs this module owns back to their old,
 * unsurvivable values.
 */
export function assaultHard() {
  try {
    if (typeof location !== 'undefined' &&
      new URLSearchParams(location.search).get('assaulthard') === '1') return true;
  } catch { /* no location */ }
  try {
    if (typeof process !== 'undefined' && process?.env?.OW_ASSAULT_HARD === '1') return true;
  } catch { /* no process */ }
  return false;
}

export class AirbaseAssault {
  constructor(ctx, { wq, heat, hostiles }) {
    this.ctx = ctx;
    this.wq = wq;
    this.heat = heat;
    this.hostiles = hostiles;
    this.rng = ctx.rng.fork();
    this.disabled = assaultDisabled();
    /** Survivability tuning on (false) / reverted to the old lethality (true).
     *  The negative control for the playability gate — see `assaultHard`. */
    this.hard = assaultHard();
    /**
     * NEGATIVE CONTROL for the occupancy invariant, read by `airbaseprobe` and
     * by nothing else. True puts back the pre-fix arming path: an emplacement
     * or a jeep is live because it is OURS and is not the car the player is
     * sitting in RIGHT NOW, rather than because somebody is aboard — which is
     * the build in which a tank the player steps out of turns round and shells
     * him. It changes nothing else about the encounter.
     */
    this.debugArmAbandoned = false;

    this.chase = new JetChase(ctx, wq, this.rng.fork());

    /** The published layout — resolved lazily off `world.airbase`. */
    this.ab = null;
    this._seeded = false;

    this.armed = false;
    this.guards = [];
    this.tanks = [];
    this.jets = [];
    this.jeeps = [];

    this._waveT = 0;
    this._alarmT = 0;
    this._warnT = 0;
    this._outT = 0;
    this._losT = 0;
    this._losBroken = false;
    this._jeepsStopped = true;
    /** Seconds this engagement has been armed — drives the spin-up grace, the
     *  guard concurrency ramp and the fire bracket. Reset on every arm. */
    this._armT = 0;
    /** Shared cooldown so no two emplacements fire inside FIRE_STAGGER. */
    this._fireLockT = 0;

    /* ---- scratch: nothing in update() allocates ---- */
    this._v = new THREE.Vector3();
    this._aim = new THREE.Vector3();
    this._aim2 = new THREE.Vector3();
    this._muz = new THREE.Vector3();
    this._dir = new THREE.Vector3();
    this._alarmAt = new THREE.Vector3();
    this._q = new THREE.Quaternion();
    this._jeepInp = { throttle: 0, brake: 0, steer: 0, handbrake: false, boost: false };
    this._zeroInp = Object.freeze({ throttle: 0, brake: 0, steer: 0, handbrake: false, boost: 0 });
    this._cand = new Array(32); // muster-point coordinates, reused
    this._lo = { a: 0, d: 0 };  // field-local scratch for the fence distance
  }

  init() {
    this._offs = [
      this.ctx.events.on('vehicle:enter', (e) => this._onEnter(e)),
    ];
    return this;
  }

  /** Alive guards on their feet — reads the EMITTED population, not a count. */
  get guardCount() {
    let n = 0;
    for (let i = 0; i < this.guards.length; i++) {
      const g = this.guards[i];
      if (g.active && g.alive && g.isHostile) n++;
    }
    return n;
  }

  /** Diagnostics for `game.stats` and the probe. Menu-rate, may allocate. */
  get stats() {
    return {
      on: !!this.ab,
      disabled: this.disabled,
      hard: this.hard,
      armed: this.armed,
      armT: +this._armT.toFixed(2),
      guardCap: this._guardCap(),
      guards: this.guardCount,
      tanks: this.tanks.length,
      // Machines with a live crew aboard — the only ones that may operate.
      tanksCrewed: this.tanks.reduce((n, t) => n + (this._crewed(t.v) ? 1 : 0), 0),
      jets: this.jets.length,
      jeeps: this.jeeps.length,
      jeepsCrewed: this.jeeps.reduce((n, j) => n + (this._crewed(j) ? 1 : 0), 0),
      chase: this.chase.active,
      chasePhase: this.chase.phase,
      pursuers: this.chase.count,
      outT: +this._outT.toFixed(2),
    };
  }

  /** Concurrent guard ceiling RIGHT NOW — ramps from GUARD_CAP0 to GUARD_CAP
   *  over GUARD_CAP_RAMP seconds of engagement, so the first wave is a
   *  firefight and lingering brings the whole garrison. Full cap under `hard`. */
  _guardCap() {
    if (this.hard) return GUARD_CAP;
    const t = Math.max(0, this._armT);
    return Math.min(GUARD_CAP,
      GUARD_CAP0 + Math.floor((GUARD_CAP - GUARD_CAP0) * (t / GUARD_CAP_RAMP)));
  }

  /** Seconds of spin-up before the guns are lethal — zero under `hard`. */
  _grace() {
    return this.hard ? 0 : GRACE_SPINUP;
  }

  /**
   * IS ANYBODY IN IT? The one question both loops below ask before they touch
   * a machine, and the whole of the fix for "the tank I got out of is shooting
   * at me".
   *
   * It reads the vehicle's OWN published occupancy — the seat, the riders, and
   * the garrison crew slot this file seats — rather than any list of ours: a
   * bookkeeping answer is exactly what the pre-fix path had, and a machine's
   * list membership is not evidence that a man is in it. Deliberately the same
   * fields (and the same `alive`/`active` rule) as `crewOf` in
   * `vehicles/tank.js`, because there is one fact here with two readers; it is
   * duck-typed rather than imported because `game` may not reach into
   * `src/vehicles/` (ARCHITECTURE.md rule 2).
   */
  _crewed(v) {
    if (!v) return false;
    const aboard = (a) => !!a && a.alive !== false && a.active !== false;
    if (aboard(v.driver)) return true;
    const occ = v.occupants;
    if (Array.isArray(occ)) {
      for (let i = 0; i < occ.length; i++) if (aboard(occ[i])) return true;
    }
    return aboard(v.aiCrew);
  }

  /**
   * The player has taken this machine: its crew is out of it, permanently.
   * Nothing here ever puts one back, so the vehicle is inert scenery from the
   * moment he steps out again — which is the reported behaviour, and the
   * reason this is a one-way door rather than a flag that flips with the seat.
   */
  _uncrew(v) {
    /**
     * THE NEGATIVE CONTROL LIVES HERE, and it is a restoration rather than a
     * bypass: under `debugArmAbandoned` the crew is simply never displaced, so
     * the machine is still manned by its own published state and the firing
     * gate in `tank.js` passes it honestly. Emitted behaviour is the pre-fix
     * one — step out of the tank and it shells you — which is what the probe
     * has to be able to see for the fixed arm to mean anything.
     */
    if (this.debugArmAbandoned) return false;
    if (!v || !v.aiCrew) return false;
    v.aiCrew = null;
    v.turretAimActive = false;
    // Hand the controls back at rest: a jeep whose crew has just been hauled
    // out must not coast away on the throttle the patrol loop last wrote.
    this.wq.vehicles?.setInput?.(v, this._zeroInp);
    return true;
  }

  /* ================================================================== */
  /* frame                                                              */
  /* ================================================================== */

  update(dt) {
    const ab = this.ab ?? this._resolve();
    if (!ab) return;
    if (!this._seeded) this._seed(ab);

    // Prune wrecked armour / stolen handles out of the emplacement list.
    for (let i = this.tanks.length - 1; i >= 0; i--) {
      const t = this.tanks[i];
      if (!t.v || t.v.destroyed) this.tanks.splice(i, 1);
    }
    for (let i = this.guards.length - 1; i >= 0; i--) {
      const g = this.guards[i];
      if (!g.active || !g.isHostile) this.guards.splice(i, 1);
    }

    const pos = this.wq.focusPos();
    const px = pos.x;
    const pz = pos.z;
    const py = pos.y;
    const inside = typeof ab.insidePerimeter === 'function' && ab.insidePerimeter(px, pz);
    const playerAlive = !(this.wq.player?.dead);

    if (!this.disabled && inside && !this.armed && playerAlive) this._arm(px, pz);

    if (this.armed) {
      // The engagement clock — the spin-up grace, the guard ramp and the fire
      // bracket all read it. It advances only while the fight is joined (the
      // player inside the wire), so ducking out and back does not re-spin a
      // base that already came fully to life.
      if (inside) this._armT += dt;
      if (this._fireLockT > 0) this._fireLockT -= dt;
      this._cooldown(dt, inside, px, pz);
      this._alarm(dt, inside, px, pz);
      this._waves(dt, inside, px, pz);
      this._emplacements(dt, px, py, pz);
      this._patrol(dt, px, pz, inside);
    }

    this.chase.update(dt);
  }

  /* ================================================================== */
  /* arming and standing down                                           */
  /* ================================================================== */

  _arm(px, pz) {
    this.armed = true;
    this._outT = 0;
    this._armT = 0;
    this._fireLockT = 0;
    // The klaxon and the HUD warning fire IMMEDIATELY (the base reacts the
    // instant the wire is crossed) — but the first wave and the first shells
    // hold until the spin-up grace has elapsed, so the crossing itself is not
    // an instant crossfire.
    this._waveT = this._grace();  // first wave after the spin-up
    this._alarmT = 0;  // klaxon immediately
    this._warnT = 0;   // warning immediately
    for (const t of this.tanks) {
      t.fireT = this._grace() + 0.6 + this.rng.float() * FIRE_JITTER;
    }
    this._jeepsStopped = false;
    // The trespass, priced by the police's own table (see the header).
    this.heat?.report?.('trespass', this.wq.focusPos(), 1);
  }

  _disarm() {
    this.armed = false;
    this._outT = 0;
    this._armT = 0;
    this._fireLockT = 0;
    // Guards stand down: through the pool's despawn chokepoint.
    for (let i = this.guards.length - 1; i >= 0; i--) this.hostiles?.despawn?.(this.guards[i]);
    this.guards.length = 0;
    // Turrets stop tracking; `stepTurret` goes inert on the cleared flag.
    for (const t of this.tanks) { if (t.v) t.v.turretAimActive = false; }
    this._stopJeeps();
  }

  /**
   * Leaving the perimeter winds the encounter down. Holding line of sight
   * from the garrison slows the clock; breaking it — or being far from the
   * fence — runs it at full rate.
   */
  _cooldown(dt, inside, px, pz) {
    if (inside) {
      this._outT = 0;
      return;
    }
    // One LOS ray a second, from the first live emplacement (or a guard).
    this._losT -= dt;
    if (this._losT <= 0) {
      this._losT = 1;
      this._losBroken = !this._garrisonSees(px, pz);
    }
    const far = this._fenceDist(px, pz) > FAR_DIST;
    this._outT += dt * (far || this._losBroken ? 1 : 0.45);
    if (this._outT >= OUT_COOLDOWN) this._disarm();
  }

  _garrisonSees(px, pz) {
    const phys = this.wq.physics;
    if (!phys?.raycast) return true;
    const eye = this.tanks.length ? this.tanks[0].v?.position : this.guards[0]?.position;
    if (!eye) return false;
    this._muz.set(eye.x, eye.y + 2.4, eye.z);
    this._dir.set(px - this._muz.x, (this.wq.groundY(px, pz) + 1.4) - this._muz.y, pz - this._muz.z);
    const d = this._dir.length();
    if (d < 1) return true;
    this._dir.multiplyScalar(1 / d);
    const hit = phys.raycast(this._muz, this._dir, d, phys.MASK?.WORLD ?? 0);
    return !(hit?.hit && hit.distance < d - 3);
  }

  /** Approximate distance outside the fence, using the published layout. */
  _fenceDist(px, pz) {
    const ab = this.ab;
    if (!ab?.localAt || !ab.layout) return Infinity;
    const lo = ab.localAt(px, pz, this._lo);
    let best = Infinity;
    for (const f of [ab.layout.fieldStrip, ab.layout.fieldApron]) {
      if (!f) continue;
      const qa = Math.max(f.a0 - lo.a, lo.a - f.a1, 0);
      const qd = Math.max(f.d0 - lo.d, lo.d - f.d1, 0);
      const dd = Math.hypot(qa, qd);
      if (dd < best) best = dd;
    }
    return best;
  }

  /* ================================================================== */
  /* the klaxon and the warning                                         */
  /* ================================================================== */

  _alarm(dt, inside, px, pz) {
    this._alarmT -= dt;
    this._warnT -= dt;
    if (this._alarmT <= 0) {
      this._alarmT = ALARM_PERIOD;
      // The existing positioned siren one-shot, from the nearest gate — the
      // klaxon is a place in the world, not a head-locked jingle.
      const g = this._nearestGate(px, pz);
      if (g && this._fenceDist(px, pz) < 420) {
        this._alarmAt.set(g.x, this.wq.groundY(g.x, g.z) + 6, g.z);
        this.wq.sfx('ambient', this._alarmAt, ALARM_OPTS);
      }
    }
    if (inside && this._warnT <= 0) {
      this._warnT = WARN_PERIOD;
      this.wq.ui?.notify?.('Restricted area', 'LETHAL FORCE AUTHORIZED', 'bad');
    }
  }

  _nearestGate(px, pz) {
    const gates = this.ab?.gates;
    if (!gates?.length) return null;
    let best = null;
    let bd = Infinity;
    for (const g of gates) {
      const d = dist2(px, pz, g.x, g.z);
      if (d < bd) { bd = d; best = g; }
    }
    return best;
  }

  /* ================================================================== */
  /* guards                                                             */
  /* ================================================================== */

  _waves(dt, inside, px, pz) {
    this._waveT -= dt;
    if (this._waveT > 0 || !inside) return;
    this._waveT = WAVE_PERIOD;
    const alive = this.guardCount;
    const want = Math.min(WAVE_SIZE, this._guardCap() - alive);
    if (want <= 0) return;

    // Muster points: the published patrol loop plus the gate posts, inside
    // the annulus around the player.
    const ab = this.ab;
    let n = 0;
    const put = (x, z) => {
      const d2 = dist2(px, pz, x, z);
      if (d2 < SPAWN_MIN * SPAWN_MIN || d2 > SPAWN_MAX * SPAWN_MAX) return;
      if (n < this._cand.length) { this._cand[n++] = x; this._cand[n++] = z; }
    };
    if (ab.patrol) for (const p of ab.patrol) put(p[0], p[1]);
    if (ab.gates) for (const g of ab.gates) put(g.x, g.z);
    if (n === 0 && ab.patrol?.length) {
      // Player deep in dead ground: fall back to the nearest patrol point.
      let bx = ab.patrol[0][0];
      let bz = ab.patrol[0][1];
      let bd = Infinity;
      for (const p of ab.patrol) {
        const d2 = dist2(px, pz, p[0], p[1]);
        if (d2 < bd) { bd = d2; bx = p[0]; bz = p[1]; }
      }
      this._cand[n++] = bx;
      this._cand[n++] = bz;
    }
    if (n === 0) return;

    for (let i = 0; i < want; i++) {
      const k = (this.rng.u32() % (n >> 1)) << 1;
      const x = this._cand[k] + this.rng.range(-6, 6);
      const z = this._cand[k + 1] + this.rng.range(-6, 6);
      const g = this.hostiles?.spawn?.(x, z, GUARD_OPTS);
      if (g) this.guards.push(g);
    }
  }

  /* ================================================================== */
  /* tank emplacements                                                  */
  /* ================================================================== */

  _emplacements(dt, px, py, pz) {
    if (!this.tanks.length) return;
    const playerVeh = this.wq.playerVehicle();
    this._aim.set(px, py + 1.0, pz);
    // The ranging bracket: metres the aim point is deliberately thrown off,
    // large at first crossing and closing to zero over BRACKET_RAMP seconds.
    const bracket = this.hard ? 0
      : BRACKET_MAX * clamp01(1 - this._armT / BRACKET_RAMP);
    const graced = this._armT >= this._grace();
    for (const t of this.tanks) {
      const v = t.v;
      if (!v || v.destroyed) continue;
      // A tank the player has stolen is his, not an emplacement.
      if (v === playerVeh) continue;
      /**
       * AND A TANK WITH NOBODY IN IT IS NOT AN EMPLACEMENT EITHER — the line
       * above is about whose it is, this one is about whether anybody is
       * aboard, and only the second is the question. Without it, stepping out
       * of a captured tank handed the gun straight back to the garrison with
       * the player standing at the hatch. The turret is stood down as well as
       * the gun, so an abandoned hull does not go on tracking him.
       */
      if (!this._crewed(v)) { v.turretAimActive = false; continue; }
      const d = dist(v.position.x, v.position.z, px, pz);
      if (d > TANK_RANGE * 1.4) { v.turretAimActive = false; continue; }

      // Where THIS gun is laid: the player, offset by its own bracket vector.
      // Each emplacement brackets from a different quarter (t.bx/t.bz), so the
      // early rounds straddle the target rather than stacking on one spot.
      this._aim2.set(this._aim.x + t.bx * bracket, this._aim.y,
        this._aim.z + t.bz * bracket);

      // Track: the production stepTurret slews the emitted turret from here,
      // above the sleep gate, at the spec's bounded rates.
      v.aimTurret?.(this._aim2);

      // Fire control: the spin-up grace, the shared shell stagger, cadence,
      // envelope, hold-fire under a live chase, LOS, and only once the EMITTED
      // turret actually bears on its (bracketed) aim point.
      t.fireT -= dt;
      if (t.fireT > 0) continue;
      if (!graced) continue;                           // base still spinning up
      if (this._fireLockT > 0) continue;               // another gun just fired
      if (this.chase.active) continue;                 // interceptors own it
      if (d < TANK_MIN || d > TANK_RANGE) continue;
      if (!this._turretOnTarget(v, this._aim2)) continue;
      if (!this._tankSees(v, px, py, pz, d)) continue;
      if (v.fireShell?.() ?? null) {
        t.fireT = FIRE_PERIOD + this.rng.float() * FIRE_JITTER;
        this._fireLockT = this.hard ? 0 : FIRE_STAGGER;
      }
    }
  }

  /**
   * Does the emitted turret bear on the commanded point? The same body-frame
   * yaw the slew solves, compared against the PUBLISHED `turretYaw` state
   * that `syncTransforms` draws.
   */
  _turretOnTarget(v, aim = this._aim) {
    const st = v.spec?.style;
    if (!st?.turret) return false;
    this._muz.set(st.turret.x ?? 0, st.turret.y + (st.gun?.y ?? 0.3) - v.spec.comY, st.turret.z)
      .applyQuaternion(v.quaternion).add(v.position);
    this._dir.copy(aim).sub(this._muz)
      .applyQuaternion(this._q.copy(v.quaternion).invert());
    const wantYaw = Math.atan2(this._dir.x, this._dir.z);
    return Math.abs(wrapAngle(wantYaw - (v.turretYaw ?? 0))) < AIM_TOL;
  }

  _tankSees(v, px, py, pz, d) {
    const phys = this.wq.physics;
    if (!phys?.raycast) return true;
    this._muz.set(v.position.x, v.position.y + 2.3, v.position.z);
    this._dir.set(px - this._muz.x, py + 1.0 - this._muz.y, pz - this._muz.z);
    const len = this._dir.length();
    if (len < 1) return false;
    this._dir.multiplyScalar(1 / len);
    const hit = phys.raycast(this._muz, this._dir, len, phys.MASK?.WORLD ?? 0);
    void d;
    return !(hit?.hit && hit.distance < len - 3);
  }

  /* ================================================================== */
  /* patrol jeeps                                                       */
  /* ================================================================== */

  _patrol(dt, px, pz, inside) {
    void dt;
    const veh = this.wq.vehicles;
    if (!veh?.setInput) return;
    const playerVeh = this.wq.playerVehicle();
    for (let i = this.jeeps.length - 1; i >= 0; i--) {
      const j = this.jeeps[i];
      if (!j || j.destroyed) { this.jeeps.splice(i, 1); continue; }
      if (j === playerVeh) continue;
      // Nobody at the wheel, nobody driving. A jeep the player abandoned by
      // the fence sits there; it does not resume the chase without its crew.
      if (!this._crewed(j)) continue;
      if (!inside) { veh.setInput(j, this._zeroInp); continue; }
      driveToward(veh, j, this._jeepInp, px, pz, JEEP_DRIVE);
    }
    this._jeepsStopped = false;
  }

  _stopJeeps() {
    if (this._jeepsStopped) return;
    this._jeepsStopped = true;
    const veh = this.wq.vehicles;
    const playerVeh = this.wq.playerVehicle();
    for (const j of this.jeeps) {
      if (j && !j.destroyed && j !== playerVeh) veh?.setInput?.(j, this._zeroInp);
    }
  }

  /* ================================================================== */
  /* the stolen jet                                                     */
  /* ================================================================== */

  _onEnter(e) {
    if (this.disabled || !e?.vehicle) return;
    if (e.actor && e.actor !== this.wq.player) return;
    const ab = this.ab;
    const v = e.vehicle;
    /**
     * THE CREW COMES OUT WHEN HE GETS IN. He cannot be in the seat and they
     * cannot still be manning it, and this is the ONE place that says so — so
     * stepping back out leaves a dead machine rather than an emplacement that
     * re-arms on the frame the ownership test flips. One way: nothing here
     * ever crews one again.
     */
    for (const t of this.tanks) if (t.v === v) this._uncrew(v);
    for (const j of this.jeeps) if (j === v) this._uncrew(v);
    if (!ab || v.spec?.id !== 'jet') return;
    if (typeof ab.insidePerimeter !== 'function' ||
      !ab.insidePerimeter(v.position.x, v.position.z)) return;
    if (this.chase.active) return;
    // Boarding the jet is the theft; the base goes to full alert with it.
    if (!this.armed) this._arm(v.position.x, v.position.z);
    if (this.chase.begin(v, ab)) {
      this.wq.ui?.notify?.('Stolen military jet', 'GET AIRBORNE', 'bad');
    }
  }

  /* ================================================================== */
  /* seeding                                                            */
  /* ================================================================== */

  _resolve() {
    const ab = this.wq.world?.airbase;
    if (!ab?.pad || !ab.insidePerimeter) return null;
    this.ab = ab;
    return ab;
  }

  /**
   * Dress the published apron: jets on the jet stands, armour on the tank
   * stands, two patrol Overlooks by the gate road. Parked scenery until the
   * encounter arms; the jets are also what the player steals. Runs once.
   */
  _seed(ab) {
    this._seeded = true;
    const veh = this.wq.vehicles;
    if (typeof veh?.spawn !== 'function' || !Array.isArray(ab.apronSlots)) return;
    const at = (slot, type, opts) => {
      const comY = veh.specOf?.(type)?.comY ?? 1;
      const y = this.wq.groundY(slot.x, slot.z) + comY + 0.02;
      return veh.spawn(type, this._v.set(slot.x, y, slot.z), slot.heading, opts ?? EMPTY_OPTS);
    };
    let jets = 0;
    let tanks = 0;
    let jeeps = 0;
    for (const slot of ab.apronSlots) {
      if (slot.kind === 'jet' && jets < JET_N) {
        const v = at(slot, 'jet');
        if (v) { this.jets.push(v); jets++; }
      } else if (slot.kind === 'tank' && tanks < TANK_N) {
        const v = at(slot, 'tank');
        if (v) {
          // MANNED. The crew is what makes it an emplacement rather than a
          // parked hull, and it is the only thing that does — see `_crewed`.
          // A record per machine, not a shared one, so killing or displacing
          // one crew cannot silence the rest. Seeding runs once: allocating
          // here is an arm-edge cost, never a frame cost (rule 5).
          v.aiCrew = { tag: 'airbase', role: 'gun', alive: true };
          // A fixed bracket bearing per gun, so the ranging rounds straddle the
          // target from different quarters instead of stacking on one point.
          const a = this.rng.range(-Math.PI, Math.PI);
          this.tanks.push({ v, fireT: 2, bx: Math.sin(a), bz: Math.cos(a) });
          tanks++;
        }
      } else if (slot.kind === 'jeep' && jeeps < JEEP_N) {
        const v = at(slot, 'suv', JEEP_OPTS);
        if (v) {
          v.aiCrew = { tag: 'airbase', role: 'patrol', alive: true };
          this.jeeps.push(v);
          jeeps++;
        }
      }
    }
  }

  /* ================================================================== */

  /**
   * Full wind-down NOW — death, respawn, dossier adoption, a 'clean' debug
   * stage. Parked scenery stays; everything hostile stands down.
   */
  reset() {
    if (this.armed) this._disarm();
    else this._stopJeeps();
    this.guards.length = 0;
    this.chase.reset();
    this._outT = 0;
  }

  dispose() {
    for (const off of this._offs ?? []) off();
    this._offs = null;
    this.reset();
    this.chase.dispose();
    this.tanks.length = 0;
    this.jets.length = 0;
    this.jeeps.length = 0;
  }
}

const EMPTY_OPTS = Object.freeze({});
/** The one-off olive-drab patrol variant — a paint override, not a class. */
const JEEP_OPTS = Object.freeze({ paint: JEEP_PAINT, finish: 'matte' });
/** The klaxon: the existing positioned siren voice, loud and near. */
const ALARM_OPTS = Object.freeze({ which: 'siren', level: 6, gain: 2.4, near: 1 });
/** Patrol driving: the shared mission steering, eased off close in. */
const JEEP_DRIVE = Object.freeze({ slow: 20, throttle: 0.85, gain: 1.6 });
