#!/usr/bin/env node
/**
 * FLIGHT PROBE — the two flyable verbs, gated on EMITTED motion.
 *
 * The player wanted to fly: helicopters he can take from the airports, and a
 * fixed-wing aircraft he can fly a circuit in and land. This file gates both,
 * at the real 120 Hz `Vehicle.fixedStep`, and it asserts the position and
 * orientation the body ACTUALLY REACHES — never `input`, never the commanded
 * rate, never a lever. (Rule 12: a gate that re-reads the code's own inputs
 * checks nothing.)
 *
 * The helicopter's own flight envelope is gated in depth by `drivetest.mjs`
 * section 11; what this file adds for the helicopter is the two things that are
 * NEW — that a parked one is ENTERABLE through the exact predicate the F-action
 * uses (`freeroam.TAKEABLE`), found by the real `VehicleSystem.nearest`, and
 * that on the current key binding (SPACE, the handbrake channel) it climbs.
 *
 * For the aeroplane it gates the whole model:
 *   - a parked plane sits still on its gear;
 *   - throttle from a standstill builds AIRSPEED, and past flying speed the
 *     body LEAVES THE GROUND and gains ALTITUDE;
 *   - NEGATIVE CONTROL: with no throttle it never leaves the runway;
 *   - cut the throttle in the air and it slows below flying speed and DESCENDS
 *     (the stall — lift goes as V², so below flying speed the wing cannot hold
 *     the weight up whatever the stick does);
 *   - W/S move the emitted pitch the right way, A/D roll it and swing the
 *     heading round in a coordinated turn, and NO roll input holds the wings
 *     level (its negative control).
 *
 * ────────────────────────────────────────────────────────────────────────────
 * THE ARRIVAL — what happens when it MEETS something
 * ────────────────────────────────────────────────────────────────────────────
 * For a long time, nothing did. An aeroplane's only contact with the world was
 * three gear springs and a probe ring built from its bounding box — and an
 * aircraft's `dims.W` is its WING SPAN, so every probe sat 5.4 m off the
 * centreline and the fuselage had none at all. A Skylark could be flown into
 * the runway at 20 m/s, or through a hangar wall at cruise, and taxi away
 * undamaged. Three sections gate that now, all on emitted quantities:
 *
 *   - THE ARRIVAL: three landings differing in ONE thing, the sink rate. 2 m/s
 *     costs nothing, 8 m/s costs health, 25 m/s is a write-off with
 *     `vehicle:destroyed` on the wire and the same burn fuse every other wreck
 *     in the city runs. Its negative control is the same aeroplane parked.
 *   - THE WALL: flown into a 6 m wall at cruise it stops AT the wall and is
 *     written off. NEGATIVE CONTROL: the same flight with the pre-fix corner
 *     ring installed on the live vehicle, which flies the fuselage 74 m (the
 *     Skylark) and 1532 m (the jet) past the wall without touching it.
 *   - THE WINGTIP: a wing into a pylon at 20 m/s — under the speed the sweep
 *     arms at, so the probe RING is the only thing that can price it — is
 *     priced at the speed it arrived at and written off. It used to be priced
 *     at 6.96 m/s, because an off-centre contact's IMPULSE over mass is not
 *     its closing speed. Its negative control is the same clip at 8 m/s.
 *   - ON ITS BACK: an inverted aircraft reports itself GROUNDED. Its gear rays
 *     point at the sky, so it used to report itself as flying — and the
 *     self-righting that is meant to recover it arms off `grounded`.
 *
 * ────────────────────────────────────────────────────────────────────────────
 * THE VARIANTS
 * ────────────────────────────────────────────────────────────────────────────
 * Two aircraft VARIANTS ride the same two flight models with their own tuning
 * and their own airframes: the SKYWATCH 6 news helicopter (`newsheli`) and the
 * SLIPSTREAM low-wing sport plane (`sportplane`). This file gates that each
 * variant is a genuinely different machine, all of it measured on the EMITTED
 * result:
 *
 *   - the news heli CLIMBS: same 14 s of collective as the Riverhop, higher
 *     emitted altitude and vertical speed. NEGATIVE CONTROL: the same spec
 *     with the Riverhop's rotor block swapped in climbs exactly like a
 *     Riverhop — the gap is the tuning, not the class name.
 *   - the sport plane is FASTER: same seconds of full throttle as the
 *     Skylark, higher emitted airspeed — and TWITCHIER: the same second of
 *     aileron banks it further. NEGATIVE CONTROL: the Skylark's flight/aero
 *     blocks under the Slipstream's silhouette collapse the speed gap to
 *     nothing.
 *   - the SILHOUETTES differ, measured on the geometry the builders emit
 *     (never the style block): the Skylark's wing sits high over the fuselage
 *     centreline where the Slipstream's sits below it, their spans differ by
 *     over a metre, and the Skywatch is the better part of 1.5 m longer than
 *     the Riverhop with a visibly bigger rotor disc. NEGATIVE CONTROL: the
 *     Slipstream rebuilt with the Skylark's wing height reads as a high-wing,
 *     so the detector measures the wing, not the id.
 *   - every aircraft is in `CLASS_IDS` — the exact table `vehicles.classes`
 *     publishes and the cheat menu enumerates its spawn rows from — each one
 *     is offered by the real F-scan predicate once spawned, and each one's
 *     seat anchor (the thing the boarding animation aims at) is finite and
 *     inside its own cabin.
 *
 * ────────────────────────────────────────────────────────────────────────────
 * THE ENVELOPE
 * ────────────────────────────────────────────────────────────────────────────
 * Everything above gates that a machine flies AT ALL. None of it moves if a
 * helicopter's transit speed halves, which is the one thing a player feels
 * first — so section 6 floors the emitted transit: top speed along the nose and
 * time to gain 100 m, for both rotorcraft high and nap-of-the-earth, and top
 * speed and best climb for all three fixed-wings. With it, the A/B that says
 * `dynamics.js`'s shared roll stability and self-righting cannot reach a flight
 * model at all, and the assertion that no rotorcraft carries the fixed-wing
 * fuselage probe ring.
 *
 * Every threshold below is a MEASURED emitted quantity with a margin, and the
 * negative controls are run so the positive assertions mean something.
 *
 *   node src/vehicles/flightprobe.mjs
 */

import * as THREE from 'three';
import { VEHICLE_SPECS, CLASS_IDS, PAINTS, finalizeSpec, SURFACE_GRIP } from './specs.js';
import { Vehicle } from './dynamics.js';
import { VehicleSystem } from './index.js';
import { DamageModel } from './damage.js';
import { buildHeliBody } from './heli.js';
import { buildPlaneBody } from './plane.js';
import { buildJetBody } from './jet.js';

const DT = 1 / 120;
const DEG = 180 / Math.PI;

let pass = 0;
let fail = 0;
const fails = [];
function check(section, label, ok, detail) {
  if (ok) pass++;
  else { fail++; fails.push(`${section}: ${label} — ${detail}`); }
  if (!ok || process.argv.includes('--verbose')) {
    console.log(`${ok ? 'PASS' : 'FAIL'}  [${section}] ${label}  (${detail})`);
  }
}

/* ------------------------------------------------------------------ */
/* A flat concrete world — the runway. Same shape drivetest uses.      */
/* ------------------------------------------------------------------ */
function makeWorld(slopeDeg = 0) {
  const a = (slopeDeg * Math.PI) / 180;
  const N = new THREE.Vector3(0, Math.cos(a), Math.sin(a)).normalize();
  const HIT = { hit: true, point: new THREE.Vector3(), normal: N.clone(), distance: 0, surface: 'concrete', object: null };
  const grip = {};
  for (const k in SURFACE_GRIP) grip[k] = { ...SURFACE_GRIP[k] };
  return {
    slope: 0,
    physics: {
      MASK: { WORLD: 3 }, staticWorld: null,
      raycast(o, d, maxDist) {
        const dn = N.dot(d);
        if (Math.abs(dn) < 1e-6) { HIT.hit = false; return HIT; }
        const t = -N.dot(o) / dn;
        if (t < 0 || t > maxDist) { HIT.hit = false; return HIT; }
        HIT.hit = true; HIT.distance = t;
        HIT.point.set(o.x + d.x * t, o.y + d.y * t, o.z + d.z * t);
        HIT.normal.copy(N); return HIT;
      },
      // Ground plane through the origin with normal N: y = -(N.z z)/N.y.
      groundHeight: (x, z) => -(N.z * z) / N.y,
    },
    slope: a,
    lodOf: () => 0,
    surfaceAt: () => 'concrete',
    waterHeightAt: () => null,
    /**
     * THE REAL ONE, not a stub. `VehicleSystem.reportCollision` is what turns a
     * reported contact into panel damage, `vehicle:collision` and
     * `vehicle:destroyed`, and the arrival section below is a claim about all
     * three — so it runs the shipped method against this fake system, the same
     * way the enter section runs the shipped `nearest` and `seatAnchor`. A
     * stub here would have made "a crash writes the aeroplane off" a statement
     * about the harness.
     */
    reportCollision(...args) {
      return VehicleSystem.prototype.reportCollision.apply(this, args);
    },
    gripOf: (n) => grip[n] ?? grip.asphalt,
    _world: () => null,
    ctx: CTX,
  };
}
const STUB = { root: null, wheels: [], panels: [], glassMeshes: [], lampMats: {} };
/**
 * A recording context. `events` is the wire every other subsystem hears a
 * crash on, so the arrival section asserts on what came out of it rather than
 * on a flag the vehicle set on itself.
 */
const EVENTS = [];
const CTX = {
  events: { emit(id, payload) { EVENTS.push({ id, payload }); } },
  peek: () => null,
  time: { elapsed: 0 },
};

function spawnSpec(spec, { driver = true, slope = 0 } = {}) {
  const v = new Vehicle(makeWorld(slope), spec, STUB, {});
  v.damage = null;
  // Rest the gear/skids on the ground: CoM sits one gear-drop above it.
  // Keyed on KIND, not on the class id, so every variant of either flight
  // model is seated the way its own contact geometry dictates.
  const drop = spec.kind === 'heli'
    ? spec.comY - (spec.style.skidY - spec.style.skidR)
    : spec.comY - spec.style.gearY;
  v.setPose(new THREE.Vector3(0, drop, 0), 0);
  if (driver) v.driver = { isPlayer: true };
  // A player at the controls gets the auto-reverse steer sign; matching it here
  // keeps the A/D roll direction identical in the gate and in the game.
  v.autoReverse = true;
  return v;
}
function spawn(type, opts = {}) {
  return spawnSpec(finalizeSpec(VEHICLE_SPECS[type]), opts);
}
/**
 * `input` may be an object, or a FUNCTION of the vehicle evaluated per step —
 * the envelope section flies closed-loop profiles (hold this height, then push
 * the cyclic) that a fixed input cannot express. `onStep` samples the emitted
 * state after each step, which is the only place a peak can be read.
 */
function fly(v, input, seconds, onStep) {
  const n = Math.round(120 * seconds);
  const fn = typeof input === 'function';
  for (let i = 0; i < n; i++) {
    const inp = fn ? input(v) : input;
    v.input.throttle = inp.throttle ?? 0;
    v.input.brake = inp.brake ?? 0;
    v.input.steer = inp.steer ?? 0;
    v.input.handbrake = !!inp.handbrake;
    v.input.boost = inp.boost ?? 0;
    v.fixedStep(DT, CTX);
    if (onStep) onStep(v, i);
  }
  return v;
}

const _f = new THREE.Vector3();
const _r = new THREE.Vector3();
const _u = new THREE.Vector3();
function basis(v) {
  _f.set(0, 0, 1).applyQuaternion(v.quaternion);
  _r.set(1, 0, 0).applyQuaternion(v.quaternion);
  _u.set(0, 1, 0).applyQuaternion(v.quaternion);
}
const fwdSpeed = (v) => { basis(v); return v.velocity.dot(_f); };
const pitchOf = (v) => { basis(v); return Math.asin(Math.max(-1, Math.min(1, _f.y))); };
const bankOf = (v) => { basis(v); return Math.atan2(_r.y, _u.y); };
const headingOf = (v) => { basis(v); return Math.atan2(_f.x, _f.z); };
function sideslip(v) {
  const q = v.quaternion.clone().invert();
  const vb = v.velocity.clone().applyQuaternion(q);
  return Math.atan2(vb.x, Math.max(Math.abs(vb.z), 2));
}

/* ================================================================== */
/* 1. THE ENTER PATH — a parked machine is offered by F               */
/* ================================================================== */
/**
 * `freeroam._vehicleNear` scans `vehicles.nearest(x,y,z, R.enter, TAKEABLE)`
 * and `TAKEABLE(v) = !!v && !v.destroyed && v.enterable !== false`. Both halves
 * are exercised against the REAL `VehicleSystem.nearest` and the REAL predicate
 * — not a re-read of a flag the spawn code set.
 */
function TAKEABLE(v) { return !!v && !v.destroyed && v.enterable !== false; }

/** Every flyable class. The variants ride the same two kinds. */
const AIRCRAFT = ['heli', 'newsheli', 'plane', 'sportplane', 'jet'];

function testEnter() {
  for (const [type, ap] of [
    ['heli', [-1072, 784]], ['plane', [1032, -784]],
    // The variants spawn from the cheat menu wherever the player is standing;
    // the coordinates are arbitrary open ground, which is exactly the claim.
    ['newsheli', [220, -410]], ['sportplane', [-380, 96]], ['jet', [510, 120]],
  ]) {
    const v = spawn(type);
    v.position.set(ap[0], 0.6, ap[1]);
    const sys = { vehicles: [v] };
    const found = VehicleSystem.prototype.nearest.call(sys, ap[0], 1.5, ap[1], 6, TAKEABLE);
    check('enter', `a parked ${type} is offered by the F scan`,
      found === v && v.enterable !== false,
      `nearest returned ${found === v ? 'it' : found}, enterable=${v.enterable}`);
    // A wreck is not takeable — the other half of the predicate.
    v.destroyed = true;
    const gone = VehicleSystem.prototype.nearest.call(sys, ap[0], 1.5, ap[1], 6, TAKEABLE);
    check('enter', `a destroyed ${type} is NOT offered`, gone === null,
      `nearest returned ${gone === null ? 'null' : 'it'}`);
  }

  /**
   * THE CHEAT MENU'S TABLE. `src/ui/cheats.js` builds its spawn rows from
   * `vehicles.classes`, and `VehicleSystem` publishes `this.classes =
   * CLASS_IDS` — so membership in CLASS_IDS IS the wiring: an aircraft in this
   * table gets a SPAWN row with no edit to the menu, and one missing from it
   * cannot be offered at all.
   */
  for (const id of AIRCRAFT) {
    check('cheats', `${id} is in CLASS_IDS (the table the cheat menu enumerates)`,
      CLASS_IDS.includes(id), `CLASS_IDS: ${CLASS_IDS.join(',')}`);
  }

  /**
   * THE SEAT. `nearest` offering a machine is only half of enterable — the
   * boarding animation aims at `seatAnchor`, and for a fixed-wing that runs
   * the GENERIC cabin path, which reads style fields (`sillY`, `beltY`,
   * `cowlZ`) no aircraft used to carry: the emitted anchor was NaN. Assert the
   * anchor the real method emits is finite and the head sits inside the
   * machine's own cabin — between the cockpit floor and the roof, between the
   * cabin bulkheads.
   */
  for (const id of AIRCRAFT) {
    const v = spawn(id);
    v.position.set(50, 1.4, -20);
    const a = VehicleSystem.prototype.seatAnchor.call({}, v, 0);
    const finite = !!a && [a.position.x, a.position.y, a.position.z,
      a.enter.x, a.enter.y, a.enter.z, a.yaw].every(Number.isFinite);
    const st = v.spec.style;
    const headY = finite ? a.local.y + v.spec.comY : NaN;
    const inCabin = finite &&
      headY > st.floorY + 0.4 && headY < st.roofY &&
      a.local.z > (st.cabinZ0 ?? -2) - 0.05 && a.local.z < (st.cabinZ1 ?? 2) + 0.05;
    check('cheats', `${id} seat anchor is finite and inside the cabin`,
      finite && inCabin,
      finite
        ? `head y ${headY.toFixed(2)} (floor ${st.floorY}, roof ${st.roofY}), z ${a.local.z.toFixed(2)} in [${st.cabinZ0}, ${st.cabinZ1}]`
        : 'anchor is not finite');
  }
}

/* ================================================================== */
/* 2. HELICOPTER — enterable, and it climbs on SPACE                  */
/* ================================================================== */
function testHeli() {
  const v = spawn('heli');
  const y0 = v.position.y;
  fly(v, {}, 2);
  const idle = v.position.y - y0;
  // SPACE is the handbrake channel, and per the current binding it climbs.
  fly(v, { handbrake: true }, 14);
  const climbed = v.position.y - y0;
  check('heli', 'sits still on its skids with no collective', Math.abs(idle) < 0.05,
    `drifted ${idle.toFixed(4)} m in 2 s`);
  check('heli', 'climbs on SPACE (the handbrake channel)', climbed > 60 && v.velocity.y > 6,
    `+${climbed.toFixed(1)} m in 14 s at ${v.velocity.y.toFixed(2)} m/s, alt ${v.altitude.toFixed(1)} m`);

  // NEGATIVE CONTROL: nothing held, a spooled machine stays on the ground.
  const n = spawn('heli');
  const ny = n.position.y;
  fly(n, {}, 16);
  check('heli', 'NEGATIVE CONTROL — no collective, no climb',
    Math.abs(n.position.y - ny) < 0.1 && n.grounded >= 3,
    `moved ${(n.position.y - ny).toFixed(3)} m in 16 s, ${n.grounded} skids down`);
}

/* ================================================================== */
/* 3. AEROPLANE — the whole flight model                              */
/* ================================================================== */
function testPlane() {
  /* ---- parked: sits still on its gear -------------------------------- */
  {
    const v = spawn('plane');
    const p0 = v.position.clone();
    fly(v, {}, 3);
    const drift = Math.hypot(v.position.x - p0.x, v.position.z - p0.z);
    check('plane', 'parked, it settles on its gear and sits still',
      v.grounded >= 3 && Math.abs(v.velocity.y) < 0.1 && v.altitude < 0.15 && drift < 0.2,
      `grounded ${v.grounded}, vy ${v.velocity.y.toFixed(4)}, alt ${v.altitude.toFixed(3)}, drift ${drift.toFixed(3)} m`);
  }

  /* ---- parked on a SLOPE: it holds and settles, does not creep ------ */
  // The airfields sit on natural, gently sloped ground. It must not slide off.
  {
    const parked = spawn('plane', { driver: false, slope: 5 });
    fly(parked, {}, 3);              // settle onto the slope
    const p0 = parked.position.clone();
    fly(parked, {}, 6);
    const creep = Math.hypot(parked.position.x - p0.x, parked.position.z - p0.z);
    check('plane', 'parked on a 5 deg slope it settles and holds, no creep',
      creep < 0.4 && parked.grounded >= 3,
      `drifted ${creep.toFixed(3)} m in 6 s, ${parked.grounded} wheels down`);
  }

  /* ---- throttle builds airspeed, and it takes off -------------------- */
  {
    const v = spawn('plane');
    fly(v, { boost: 1 }, 12);
    const vRoll = fwdSpeed(v);
    check('plane', 'throttle from a standstill builds airspeed', vRoll > 25,
      `${vRoll.toFixed(1)} m/s along the nose after 12 s of throttle`);
    fly(v, { boost: 1 }, 14);
    check('plane', 'past flying speed it leaves the ground and climbs',
      v.altitude > 40 && v.velocity.y > 3,
      `altitude ${v.altitude.toFixed(1)} m, climb ${v.velocity.y.toFixed(2)} m/s`);
  }

  /* ---- NEGATIVE CONTROL: no throttle, no take-off -------------------- */
  {
    const v = spawn('plane');
    const y0 = v.position.y;
    fly(v, {}, 26);
    check('plane', 'NEGATIVE CONTROL — no throttle, it never leaves the runway',
      fwdSpeed(v) < 2 && v.altitude < 0.2 && Math.abs(v.position.y - y0) < 0.1 && v.grounded >= 3,
      `airspeed ${fwdSpeed(v).toFixed(2)} m/s, altitude ${v.altitude.toFixed(3)} m, ${v.grounded} wheels down`);
  }

  /* ---- the stall: below flying speed it descends -------------------- */
  {
    const v = spawn('plane');
    fly(v, { boost: 1 }, 26);
    const vCruise = fwdSpeed(v);
    // Chop the throttle (SPACE winds the lever down) and hold nothing else. It
    // trades what speed it has for a little height first (the phugoid), so the
    // claim is measured on a LATER window: once slow, is it losing altitude?
    fly(v, { handbrake: true }, 8);
    const altA = v.altitude;
    const vSlow = fwdSpeed(v);
    fly(v, { handbrake: true }, 6);
    const altB = v.altitude;
    check('plane', 'chop the throttle and airspeed bleeds off below flying speed',
      vSlow < vCruise - 8 && vSlow < 36,
      `${vCruise.toFixed(1)} -> ${vSlow.toFixed(1)} m/s`);
    check('plane', 'below flying speed the wing stalls and it descends',
      v.velocity.y < -2 && altB < altA - 5,
      `sink ${v.velocity.y.toFixed(2)} m/s, altitude ${altA.toFixed(1)} -> ${altB.toFixed(1)} m over the last 6 s`);
  }

  /* ---- pitch: W noses down, S noses up ------------------------------ */
  {
    const base = () => { const v = spawn('plane'); fly(v, { boost: 1 }, 18); return v; };
    const up = base(); fly(up, { boost: 0.5, brake: 1 }, 1.5);   // S
    const dn = base(); fly(dn, { boost: 0.5, throttle: 1 }, 1.5); // W
    const pUp = pitchOf(up), pDn = pitchOf(dn);
    check('plane', 'the elevator pitches it — S up, W down', pUp - pDn > 0.21,
      `pitch S ${(pUp * DEG).toFixed(1)} deg vs W ${(pDn * DEG).toFixed(1)} deg`);
  }

  /* ---- roll / yaw: A/D bank it and swing the heading, coordinated --- */
  {
    const base = () => { const v = spawn('plane'); fly(v, { boost: 1 }, 18); return v; };
    // This gate spawns a PLAYER at the controls (`autoReverse = true`, above) to
    // keep the A/D roll direction identical in the gate and in the game — so it
    // tracks the PLAYER ROLL SWAP in plane.js. For a human pilot D now banks the
    // plane the SAME way the helicopter does (the un-inverted direction the
    // player asked for): D (steer +1) rolls LEFT — the left wing drops (bank > 0)
    // and the heading swings left (heading decreases).
    const rt = base(); const hR0 = headingOf(rt);
    fly(rt, { boost: 0.6, steer: 1 }, 1.2);
    const bankR = bankOf(rt), dHR = headingOf(rt) - hR0, slipR = sideslip(rt);
    // A (steer -1): roll RIGHT — bank < 0, heading swings right.
    const lf = base(); const hL0 = headingOf(lf);
    fly(lf, { boost: 0.6, steer: -1 }, 1.2);
    const bankL = bankOf(lf), dHL = headingOf(lf) - hL0;

    check('plane', 'D rolls left and the heading swings left (the swapped player direction)',
      bankR > 0.12 && dHR < -0.05,
      `bank ${(bankR * DEG).toFixed(1)} deg, heading ${(dHR * DEG).toFixed(1)} deg`);
    check('plane', 'A rolls right and the heading swings right',
      bankL < -0.12 && dHL > 0.05,
      `bank ${(bankL * DEG).toFixed(1)} deg, heading +${(dHL * DEG).toFixed(1)} deg`);
    check('plane', 'the banked turn stays coordinated (sideslip bounded)',
      Math.abs(slipR) < 25 / DEG,
      `sideslip ${(slipR * DEG).toFixed(1)} deg`);

    // NEGATIVE CONTROL: no aileron, the wings stay level and it flies straight.
    const st = base(); const hS0 = headingOf(st);
    fly(st, { boost: 0.6 }, 1.2);
    check('plane', 'NEGATIVE CONTROL — no aileron, wings stay level',
      Math.abs(bankOf(st)) < 0.09 && Math.abs(headingOf(st) - hS0) < 0.05,
      `bank ${(bankOf(st) * DEG).toFixed(1)} deg, heading drift ${((headingOf(st) - hS0) * DEG).toFixed(1)} deg`);
  }
}

/* ================================================================== */
/* 3b. THE ARRIVAL — a landing, a heavy landing, and a crash          */
/* ================================================================== */
/**
 * Three arrivals down the SAME code path, differing in ONE emitted quantity —
 * the sink rate the gear meets the runway at. That is what makes this an A/B
 * and not three anecdotes: nothing else about the aircraft, the world or the
 * inputs changes between the arms.
 *
 *   2 m/s   a normal approach. Not a scratch, and it must stay that way — a
 *           model that damages every landing is worse than one that damages
 *           none.
 *   8 m/s   a heavy landing. Past the gear's limit, under the airframe's:
 *           health comes off and the machine still flies home.
 *   25 m/s  flown into the ground. A write-off, `vehicle:destroyed` on the
 *           wire, and the SAME burn fuse every wreck in the city runs — which
 *           is the point of routing it through `applyImpact` rather than
 *           giving aircraft a private death.
 *
 * Everything asserted is either the emitted health, the emitted `destroyed`
 * state, or an event that actually reached `ctx.events`.
 */
/**
 * THE HANGAR WALL: a 6 m wide, 0.6 m thick slab across the runway at z = `at`,
 * solid to the probe ring and to the swept capsule cast the way a real wall is
 * solid to both.
 *
 * SIX METRES WIDE IS THE POINT. It is narrower than any wing in the fleet and
 * wider than any fuselage, so it separates the two probe rings exactly: a ring
 * built from the bounding box has its probes out at the WINGTIPS (an
 * aeroplane's `dims.W` is its SPAN) and passes either side of this wall
 * without touching it, while a ring on the fuselage centreline hits it
 * nose-first. Both arms fly the same aeroplane down the same centreline.
 */
function makeWall(at, halfWidth = 3, thick = 0.6) {
  const sys = makeWorld(0);
  const contacts = {
    depth: new Float32Array(1),
    nx: new Float32Array(1), ny: new Float32Array(1), nz: new Float32Array(1),
    px: new Float32Array(1), py: new Float32Array(1), pz: new Float32Array(1),
    tri: new Int32Array(1),
  };
  const inSlab = (x, z, r) =>
    Math.abs(x) <= halfWidth + r && z + r > at && z - r < at + thick;
  sys.physics.staticWorld = {
    contacts,
    objectOf: () => null,
    overlapCapsule(x0, y0, z0, x1, y1, z1, r) {
      const z = Math.max(z0, z1);
      if (!inSlab(x0, z, r)) return 0;
      contacts.depth[0] = Math.min(z + r - at, thick + r);
      contacts.nx[0] = 0; contacts.ny[0] = 0; contacts.nz[0] = -1;
      contacts.px[0] = x0; contacts.py[0] = y0; contacts.pz[0] = at;
      contacts.tri[0] = 0;
      return 1;
    },
  };
  sys.physics.capsuleCast = (p0, p1, radius, dir, maxDist) => {
    const lead = Math.max(p0.z, p1.z) + radius;
    const out = {
      hit: false, distance: maxDist, fraction: 1,
      point: new THREE.Vector3(), normal: new THREE.Vector3(0, 0, -1),
      object: null, surface: 'concrete',
    };
    if (dir.z <= 1e-6) return out;
    const gap = at - lead;
    if (gap > maxDist * dir.z) return out;
    const t = Math.max(0, gap / dir.z);
    const x = p0.x + dir.x * t;
    if (Math.abs(x) > halfWidth + radius) return out;
    out.hit = true;
    out.distance = t;
    out.fraction = t / maxDist;
    out.point.set(x, p0.y + dir.y * t, at);
    return out;
  };
  return sys;
}

/**
 * THE PYLON: a 5 m wide column standing off to the RIGHT of the centreline at
 * z = `at`, out where only a WING can reach it.
 *
 * It exists to isolate the one contact the hangar wall cannot produce: a hit
 * whose only probe is a LEVERED one. Down the centreline the deepest contact is
 * always the nose, whose lever arm about the CoM is parallel to the contact
 * normal and therefore zero, so the impulse solver's denominator collapses to
 * `1/m` and any pricing derived from the impulse comes out roughly right by
 * accident. Put the obstacle 4 m off the axis and the only probe that touches
 * is a wingtip, 5.1 m out — which is the case an impulse-derived delta-v gets
 * wrong by a factor of three.
 *
 * `capsuleCast` reports no hit, and that is the TRUTH here rather than a stub:
 * the swept capsule is the fuselage centreline at a 0.6 m radius and this
 * column starts 4 m off it, so the sweep genuinely never touches the pylon.
 * The ring is the only thing that can price this contact — which is the point.
 */
function makePylon(at, xLo = 4, xHi = 9, thick = 2) {
  const sys = makeWorld(0);
  const contacts = {
    depth: new Float32Array(1),
    nx: new Float32Array(1), ny: new Float32Array(1), nz: new Float32Array(1),
    px: new Float32Array(1), py: new Float32Array(1), pz: new Float32Array(1),
    tri: new Int32Array(1),
  };
  sys.physics.staticWorld = {
    contacts,
    objectOf: () => null,
    overlapCapsule(x0, y0, z0, x1, y1, z1, r) {
      const z = Math.max(z0, z1);
      if (x0 + r < xLo || x0 - r > xHi) return 0;
      if (!(z + r > at) || !(z - r < at + thick)) return 0;
      contacts.depth[0] = Math.min(z + r - at, thick + r);
      contacts.nx[0] = 0; contacts.ny[0] = 0; contacts.nz[0] = -1;
      contacts.px[0] = x0; contacts.py[0] = y0; contacts.pz[0] = at;
      contacts.tri[0] = 0;
      return 1;
    },
  };
  sys.physics.capsuleCast = (p0, p1, radius) => ({
    hit: Math.max(p0.x, p1.x) + radius > xLo && Math.min(p0.x, p1.x) - radius < xHi,
    distance: Infinity, fraction: 1,
    point: new THREE.Vector3(), normal: new THREE.Vector3(0, 0, -1),
    object: null, surface: 'concrete',
  });
  return sys;
}

/**
 * Fly one aircraft, wings level and at a HELD speed, into whatever `sys`
 * contains, and report what the contact was priced at.
 *
 * The speed is re-imposed every step so the arms differ in the one quantity
 * under test and in nothing else — this is a claim about the PRICING of a
 * contact, not about the flight model that got the aeroplane there, and that
 * model is gated to death by the envelope section already.
 */
function strike(type, sys, speed, at) {
  // Long enough for the SLOWEST arm to cover the run-in and be resolved, so a
  // negative control can never pass by simply not arriving (rule 12).
  const seconds = at / speed + 3;
  const spec = finalizeSpec(VEHICLE_SPECS[type]);
  const v = new Vehicle(sys, spec, STUB, {});
  v.damage = new DamageModel(v, MATS, probeRng());
  v.setPose(new THREE.Vector3(0, 80, 0), 0);
  v.driver = { isPlayer: true };
  const from = EVENTS.length;
  for (let i = 0; i < Math.round(seconds * 120); i++) {
    v.velocity.set(0, 0, speed);
    v.input.throttle = 0;
    v.input.steer = 0;
    v.input.brake = 0;
    v.fixedStep(DT, CTX);
    if (v.crashDv || v.position.z > at + 30) break;
  }
  return {
    dv: v.crashDv ?? 0,
    destroyed: v.destroyed,
    frac: v.health / v.maxHealth,
    hits: EVENTS.slice(from).filter((e) => e.id === 'vehicle:collision').length,
  };
}

/**
 * THE PRE-FIX PROBE RING, rebuilt from the bounding box exactly as
 * `Vehicle`'s constructor used to build it for every kind. Installed on a LIVE
 * aircraft so the wall section has a real negative control: the geometry is
 * the only thing that differs between the arms.
 */
function cornerRing(v) {
  const spec = v.spec;
  const floorLocal = (spec.style?.groundY ?? 0.14) - spec.comY;
  const roofLocal = (spec.style?.roofY ?? spec.dims.H) - spec.comY;
  const r = Math.max(0.12, Math.min(0.32, (roofLocal - floorLocal) * 0.3,
    spec.half.x * 0.5, spec.half.z * 0.3));
  const px = Math.max(0.02, spec.half.x - r);
  const pz = Math.max(0.02, spec.half.z - r);
  const yLo = floorLocal + r;
  const yHi = Math.max(yLo + 0.02, roofLocal - r);
  const probes = [];
  for (const sx of [-1, 1]) {
    for (const sz of [-1, 0, 1]) {
      probes.push(new THREE.Vector3(sx * px, yLo, sz * pz));
      if (sz !== 0) probes.push(new THREE.Vector3(sx * px * 0.8, yHi, sz * pz));
    }
  }
  v.probes = probes;
  v.probeR = r;
  // The sweep is the fuselage capsule's; a box ring never had one.
  v._fuseA = null;
  return v;
}

/** A deterministic rng for `DamageModel` — no `Math.random` anywhere. */
function probeRng(seed = 12345) {
  let s = seed >>> 0;
  const next = () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
  return { float: next, signed: () => next() * 2 - 1, fork: () => probeRng(s) };
}
/** The material calls `DamageModel` makes. The stub model has no panels. */
const MATS = {
  paint: () => ({}),
  glass: () => ({ clone: () => ({ color: { set() {} } }) }),
  cracksTexture: () => null,
};

function arrive(type, sinkRate, seconds = 4) {
  const v = spawn(type);
  v.damage = new DamageModel(v, MATS, probeRng());
  // Just clear of the runway, coming down at the rate under test.
  v.position.y += 0.5;
  v.velocity.set(0, -sinkRate, 0);
  const from = EVENTS.length;
  fly(v, {}, seconds);
  const events = EVENTS.slice(from);
  return {
    v,
    health: v.health,
    frac: v.health / v.maxHealth,
    destroyed: v.destroyed,
    dv: v.crashDv ?? 0,
    events,
  };
}

function testArrival() {
  const soft = arrive('plane', 2);
  check('arrival', 'a normal approach costs the aeroplane nothing',
    !soft.destroyed && soft.frac === 1 && soft.v.grounded >= 3,
    `health ${soft.health.toFixed(0)}/${soft.v.maxHealth}, ${soft.v.grounded} wheels down`);

  const heavy = arrive('plane', 8);
  check('arrival', 'a heavy landing damages it but does not destroy it',
    !heavy.destroyed && heavy.frac < 0.95 && heavy.frac > 0.4 && heavy.dv > 7,
    `health ${heavy.health.toFixed(0)}/${heavy.v.maxHealth} (${(heavy.frac * 100).toFixed(0)}%) at ${heavy.dv.toFixed(1)} m/s of sink`);

  const crash = arrive('plane', 25);
  check('arrival', 'flown into the ground it is written off',
    crash.destroyed && crash.health === 0 && crash.dv > 20,
    `destroyed ${crash.destroyed}, health ${crash.health.toFixed(0)}, closing ${crash.dv.toFixed(1)} m/s`);
  check('arrival', 'and `vehicle:destroyed` reaches the wire',
    crash.events.some((e) => e.id === 'vehicle:destroyed') &&
    crash.events.some((e) => e.id === 'vehicle:collision'),
    `events: ${[...new Set(crash.events.map((e) => e.id))].join(', ') || 'none'}`);

  // THE FUSE. The wreck burns and goes up on the same clock every other wreck
  // in the city runs (`DamageModel.update`), and exactly once.
  const from = EVENTS.length;
  for (let i = 0; i < 120 * 6; i++) crash.v.damage.update(DT, CTX);
  const blasts = EVENTS.slice(from).filter((e) => e.id === 'explosion');
  check('arrival', 'the wreck burns and goes up once, on the shared fuse',
    blasts.length === 1 && crash.v.burning > 0.9,
    `${blasts.length} explosion(s), burning ${crash.v.burning.toFixed(2)}, radius ${blasts[0]?.payload.radius ?? '-'}`);

  // NEGATIVE CONTROL for the whole section: the same aeroplane, the same 4 s,
  // simply parked. If a machine that never left the ground came out damaged,
  // every number above would be measuring the harness settling.
  const parked = arrive('plane', 0, 4);
  check('arrival', 'NEGATIVE CONTROL — parked, nothing is priced at all',
    !parked.destroyed && parked.frac === 1 && parked.events.length === 0,
    `health ${parked.health.toFixed(0)}, ${parked.events.length} events`);

  /**
   * INTO THE HANGAR WALL — the fuselage ring, at cruise.
   *
   * An aeroplane's `dims.W` is its WING SPAN, so the box-corner ring every
   * vehicle used to get put all twelve probes 5.4 m off the centreline and
   * left the fuselage — the nose, the cabin, the tail — with none. A Skylark
   * flew its whole body through anything narrower than its own wings and only
   * noticed if a wingtip happened to clip it.
   *
   * Both arms fly the same aircraft down the same centreline into the same
   * 6 m wall at cruise; the ONLY difference is which probe ring the body
   * carries. Asserted on the emitted position of the nose relative to the wall
   * face, and on the emitted `destroyed` state.
   */
  {
    const D = 900;
    for (const [type, seconds] of [['plane', 30], ['jet', 26]]) {
      const spec = finalizeSpec(VEHICLE_SPECS[type]);
      const nose = spec.style.noseZ ?? spec.half.z;
      const arm = (ring) => {
        const v = new Vehicle(makeWall(D), spec, STUB, {});
        v.damage = new DamageModel(v, MATS, probeRng());
        v.setPose(new THREE.Vector3(0, spec.comY - spec.style.gearY, 0), 0);
        v.driver = { isPlayer: true };
        v.autoReverse = true;
        if (ring === 'corner') cornerRing(v);
        let deepest = -Infinity;
        for (let i = 0; i < Math.round(seconds * 120); i++) {
          v.input.boost = 1;
          v.input.throttle = 0;
          v.input.brake = 0;
          v.input.steer = 0;
          v.input.handbrake = false;
          v.fixedStep(DT, CTX);
          deepest = Math.max(deepest, v.position.z + nose - D);
        }
        return { deepest, destroyed: v.destroyed, dv: v.crashDv ?? 0 };
      };
      const fuse = arm('fuselage');
      const box = arm('corner');
      check('wall', `${type}: the fuselage ring stops it AT the wall`,
        fuse.deepest < 1.5 && box.deepest > 40,
        `nose reached ${fuse.deepest.toFixed(2)} m past the face; on the old corner ring it reached ${box.deepest.toFixed(0)} m past it`);
      check('wall', `${type}: flying into it at cruise writes the airframe off`,
        fuse.destroyed && fuse.dv > 30,
        `destroyed ${fuse.destroyed} at ${fuse.dv.toFixed(0)} m/s of closing speed`);
      check('wall', `${type}: NEGATIVE CONTROL — on the corner ring the wall is not there at all`,
        !box.destroyed,
        `corner-ring arm destroyed ${box.destroyed}, nose ${box.deepest.toFixed(0)} m past the wall`);
    }
  }

  /**
   * ────────────────────────────────────────────────────────────────────────
   * THE WINGTIP — what the RING prices a contact at, in m/s
   * ────────────────────────────────────────────────────────────────────────
   * Between the sink-rate edge in `plane.js` (which hands `applyImpact` a real
   * sink rate) and `_airSweep` (which hands it a real closing speed, and only
   * arms above ~36 m/s for a Skylark), there is a whole band of speeds where
   * the fuselage probe RING is the only thing pricing an aircraft contact —
   * every building strike from `AIR_CRASH_DV` up to the arming speed.
   *
   * That path used to hand `applyImpact` `biggest / mass`, where `biggest` is
   * the collision IMPULSE. Divided by mass that is a delta-v, not a closing
   * speed: `1.12 |vn| / (1 + m n.((I^-1 (r x n)) x r))`, which collapses as the
   * contact lever grows. MEASURED on this pylon, Skylark, 20 m/s: it priced the
   * strike at 6.96 m/s and the aeroplane flew on with a repair bill.
   *
   * Three arms, all on the emitted `crashDv` and `destroyed`:
   *   20 m/s  past `AIR_CRASH_DV` — a write-off, priced at the speed it
   *           actually arrived at rather than at a third of it.
   *    8 m/s  the NEGATIVE CONTROL. Same pylon, same wing, same code path,
   *           under the threshold: damaged and still flying. Without it "it is
   *           destroyed" would pass on a model that destroys everything.
   */
  {
    const D = 60;
    const hard = strike('plane', makePylon(D), 20, D);
    check('wingtip', 'a wing into a pylon is priced at the speed it arrived at',
      hard.dv > 18 && hard.dv < 22,
      `priced at ${hard.dv.toFixed(2)} m/s of closing speed against 20.00 m/s of travel`);
    check('wingtip', 'and past `AIR_CRASH_DV` that writes the airframe off',
      hard.destroyed && hard.hits === 1,
      `destroyed ${hard.destroyed}, ${hard.hits} collision event(s)`);

    const soft = strike('plane', makePylon(D), 8, D);
    check('wingtip', 'NEGATIVE CONTROL — the same clip at 8 m/s costs a repair only',
      !soft.destroyed && soft.dv > 6 && soft.dv < 10 && soft.frac < 1,
      `priced at ${soft.dv.toFixed(2)} m/s, health ${(soft.frac * 100).toFixed(0)}%, destroyed ${soft.destroyed}`);
  }

  // ON ITS BACK: the gear points at the sky, and the aircraft must still know
  // it is on the ground — `_rightSelf` is armed off `grounded`, so an inverted
  // machine reporting itself airborne can never come back over.
  {
    const v = spawn('plane');
    v.quaternion.setFromEuler(new THREE.Euler(0, 0, Math.PI, 'YXZ'));
    v.prevQuaternion.copy(v.quaternion);
    // Resting on the fuselage crown. ONE step, and read it there: the gear
    // points are now 1.7 m up in the air and their 1.4 m rays cannot reach the
    // ground from that pose, so a non-zero count can only have come from the
    // inverted branch. (Left running, this harness has nothing to hold an
    // upside-down aeroplane up — `staticWorld` is null — and it would sink
    // through the floor until the gear rays caught it from underneath, which
    // is exactly the artefact this one-step read avoids.)
    v.position.y = v.spec.style.fuseR + 0.05;
    fly(v, {}, DT);
    basis(v);
    check('arrival', 'inverted on the apron it reports itself GROUNDED, not flying',
      v.grounded > 0 && v.airborne === 0 && v.position.y > 0 && _u.y < -0.9,
      `grounded ${v.grounded}, airborne ${v.airborne.toFixed(2)} s, up.y ${_u.y.toFixed(2)}, y ${v.position.y.toFixed(2)} m`);
  }
}

/* ================================================================== */
/* 4. THE VARIANTS — same models, measurably different machines       */
/* ================================================================== */

/** Re-finalize a structured clone with overrides — the drivetest pattern. */
function variantSpec(type, mutate) {
  const base = structuredClone(VEHICLE_SPECS[type]);
  mutate(base);
  return finalizeSpec({ ...base, _final: false });
}

function testNewsHeli() {
  // Same 14 s of collective from the same cold start, both machines. The gap
  // is the tuning (climbUp 15.5 vs 12.0), read off the EMITTED altitude.
  const climb14 = (v) => {
    const y0 = v.position.y;
    fly(v, { handbrake: true }, 14);
    return v.position.y - y0;
  };
  const news = spawn('newsheli');
  const dNews = climb14(news);
  const river = spawn('heli');
  const dRiver = climb14(river);
  check('newsheli', 'climbs on SPACE, and faster than the Riverhop',
    dNews > 120 && news.velocity.y > 14 && dNews > dRiver + 25,
    `+${dNews.toFixed(1)} m at ${news.velocity.y.toFixed(2)} m/s vs Riverhop +${dRiver.toFixed(1)} m`);

  // Idle: a spooled news machine with no collective stays on its skids.
  const idle = spawn('newsheli');
  const iy = idle.position.y;
  fly(idle, {}, 3);
  check('newsheli', 'sits still on its skids with no collective',
    Math.abs(idle.position.y - iy) < 0.05 && idle.grounded >= 3,
    `drifted ${(idle.position.y - iy).toFixed(4)} m, ${idle.grounded} skids down`);

  // NEGATIVE CONTROL: the same airframe with the RIVERHOP'S rotor block climbs
  // exactly like a Riverhop. If this "variant" still out-climbed it, the gate
  // above would be measuring the class id, not the tuning.
  const ctrl = spawnSpec(variantSpec('newsheli', (b) => {
    b.rotor = structuredClone(VEHICLE_SPECS.heli.rotor);
  }));
  const dCtrl = climb14(ctrl);
  check('newsheli', 'NEGATIVE CONTROL — with the Riverhop rotor the climb gap collapses',
    Math.abs(dCtrl - dRiver) < 8,
    `control +${dCtrl.toFixed(1)} m vs Riverhop +${dRiver.toFixed(1)} m (variant was +${dNews.toFixed(1)})`);
}

function testSportPlane() {
  /* ---- parked: settles on its gear and holds ------------------------- */
  {
    const v = spawn('sportplane');
    const p0 = v.position.clone();
    fly(v, {}, 3);
    const drift = Math.hypot(v.position.x - p0.x, v.position.z - p0.z);
    check('sportplane', 'parked, it settles on its gear and sits still',
      v.grounded >= 3 && Math.abs(v.velocity.y) < 0.1 && v.altitude < 0.15 && drift < 0.2,
      `grounded ${v.grounded}, vy ${v.velocity.y.toFixed(4)}, alt ${v.altitude.toFixed(3)}, drift ${drift.toFixed(3)} m`);
  }

  /* ---- FASTER: same 26 s of throttle as the Skylark ------------------- */
  const run26 = (v) => { fly(v, { boost: 1 }, 26); return fwdSpeed(v); };
  const sport = spawn('sportplane');
  const vSport = run26(sport);
  const lark = spawn('plane');
  const vLark = run26(lark);
  check('sportplane', 'flies off the same runway and is faster than the Skylark',
    sport.grounded === 0 && sport.altitude > 40 && vSport > 54 && vSport > vLark + 6,
    `${vSport.toFixed(1)} m/s at ${sport.altitude.toFixed(0)} m vs Skylark ${vLark.toFixed(1)} m/s`);

  /* ---- TWITCHIER: the same second of aileron banks it further --------- */
  {
    fly(sport, { boost: 0.6, steer: 1 }, 0.9);
    fly(lark, { boost: 0.6, steer: 1 }, 0.9);
    const bS = Math.abs(bankOf(sport)), bL = Math.abs(bankOf(lark));
    check('sportplane', 'the same second of aileron banks it further than the Skylark',
      bS > bL + 12 / DEG,
      `bank ${(bS * DEG).toFixed(1)} deg vs Skylark ${(bL * DEG).toFixed(1)} deg`);
  }

  /* ---- NEGATIVE CONTROL: no throttle, no take-off --------------------- */
  {
    const v = spawn('sportplane');
    fly(v, {}, 26);
    check('sportplane', 'NEGATIVE CONTROL — no throttle, it never leaves the runway',
      fwdSpeed(v) < 2 && v.altitude < 0.2 && v.grounded >= 3,
      `airspeed ${fwdSpeed(v).toFixed(2)} m/s, altitude ${v.altitude.toFixed(3)} m, ${v.grounded} wheels down`);
  }

  /* ---- NEGATIVE CONTROL: the speed is the TUNING, not the skin -------- */
  // The Skylark's flight/aero/mass under the Slipstream's silhouette must fly
  // like a Skylark. If it did not, the speed gate above would be crediting the
  // low wing's paintwork with the tuning's work.
  {
    const ctrl = spawnSpec(variantSpec('sportplane', (b) => {
      b.flight = structuredClone(VEHICLE_SPECS.plane.flight);
      b.aero = structuredClone(VEHICLE_SPECS.plane.aero);
      b.mass = VEHICLE_SPECS.plane.mass;
    }));
    const vCtrl = run26(ctrl);
    check('sportplane', 'NEGATIVE CONTROL — Skylark tuning under this skin collapses the speed gap',
      Math.abs(vCtrl - vLark) < 3,
      `control ${vCtrl.toFixed(1)} m/s vs Skylark ${vLark.toFixed(1)} m/s (variant was ${vSport.toFixed(1)})`);
  }
}

/* ================================================================== */
/* 4b. THE FIGHTER — thrust regime, runway appetite, afterburner       */
/* ================================================================== */
/**
 * The jet is `stepPlane`'s aircraft with hot numbers (see `specs.js` `jet`),
 * so what is gated here is the REGIME GAP, all of it on emitted motion:
 *
 *   - it unsticks only after a runway-length ground roll at a speed no prop
 *     in the fleet ever needs — the reason it lives on the 512-600 m military
 *     strips (`world/plan.js AIRFIELDS`) and cannot operate off a street;
 *   - the same seconds of the same input leave the sportplane an entire
 *     speed regime behind;
 *   - the AFTERBURNER measurably adds thrust: two arms flown identically to
 *     the same firewalled lever, one holding SHIFT (burner lit) and one
 *     releasing it (lever holds, burner out) — the only difference the specs
 *     allow between the arms is the reheat, and the emitted speed gap is it;
 *   - NEGATIVE CONTROLS: no throttle rolls nowhere, and the sportplane's
 *     thrust numbers under the jet's airframe cannot make the speed margin —
 *     they cannot even make it FLY — so the speed gate above is measuring
 *     the thrust block, not the silhouette.
 */
/**
 * Distance and airspeed at WHEELS-OFF: the first ground release that holds
 * for half a second of steps (a bump that skips a wheel for one frame is not
 * a take-off). Both raw emitted quantities.
 */
function rollStats(v, cap = 45) {
  const x0 = v.position.x;
  const z0 = v.position.z;
  const n = Math.round(cap * 120);
  let streak = 0;
  let roll = null;
  let unstickV = NaN;
  for (let i = 0; i < n; i++) {
    v.input.boost = 1;
    v.input.throttle = 0;
    v.input.brake = 0;
    v.input.steer = 0;
    v.input.handbrake = false;
    v.fixedStep(DT, CTX);
    if (v.grounded === 0) {
      if (streak === 0) {
        roll = Math.hypot(v.position.x - x0, v.position.z - z0);
        unstickV = fwdSpeed(v);
      }
      if (++streak >= 60) return { roll, unstickV };
    } else {
      streak = 0;
      roll = null;
    }
  }
  return { roll: null, unstickV: NaN };
}

function testJet() {
  /* ---- parked: settles on its gear and holds -------------------------- */
  {
    const v = spawn('jet');
    const p0 = v.position.clone();
    fly(v, {}, 3);
    const drift = Math.hypot(v.position.x - p0.x, v.position.z - p0.z);
    check('jet', 'parked, it settles on its gear and sits still',
      v.grounded >= 3 && Math.abs(v.velocity.y) < 0.1 && v.altitude < 0.15 && drift < 0.2,
      `grounded ${v.grounded}, vy ${v.velocity.y.toFixed(4)}, alt ${v.altitude.toFixed(3)}, drift ${drift.toFixed(3)} m`);
  }

  /* ---- the runway appetite ------------------------------------------- */
  // MEASURED: jet wheels-off at ~321 m / 90 m/s against the sportplane's
  // ~305 m / 50 m/s. The distances are close — the jet buys its speed with
  // twelve times the thrust — so the LOAD-BEARING contrast is the unstick
  // SPEED: nothing but the 512-600 m military strips gives it that run plus
  // margin to stop, and no prop in the fleet needs anything like 90 m/s.
  const jr = rollStats(spawn('jet'));
  const sr = rollStats(spawn('sportplane'));
  check('jet', 'takes off from a runway-length ground roll (fits the military strip)',
    jr.roll !== null && jr.roll > 250 && jr.roll < 470,
    `wheels-off after ${jr.roll?.toFixed(0)} m (military strips: 512/600 m)`);
  check('jet', 'unsticks at fighter speed — a far higher stall than any prop',
    sr.roll !== null && jr.unstickV > sr.unstickV + 25,
    `${jr.unstickV.toFixed(1)} m/s vs sportplane ${sr.unstickV.toFixed(1)} m/s at wheels-up`);

  /* ---- the speed regime, same seconds of the same input --------------- */
  const j26 = spawn('jet');
  fly(j26, { boost: 1 }, 26);
  const vJet = fwdSpeed(j26);
  const s26 = spawn('sportplane');
  fly(s26, { boost: 1 }, 26);
  const vSport = fwdSpeed(s26);
  check('jet', 'out-runs the sportplane by a whole regime on the same input',
    j26.grounded === 0 && j26.altitude > 40 && vJet > vSport + 40,
    `${vJet.toFixed(1)} m/s at ${j26.altitude.toFixed(0)} m vs sportplane ${vSport.toFixed(1)} m/s`);

  /* ---- afterburner: SHIFT held past the firewall vs released ---------- */
  // Two arms flown IDENTICALLY for 8 s (the lever firewalls at 1.6 s), then
  // 4 s with SHIFT held (burner lit) vs released (lever HOLDS at 1, burner
  // out) — the specs allow no difference between the arms but the reheat.
  // Measured in the climb-out where thrust dominates: at cruise the trimmed
  // wing converts extra thrust to climb angle and the airspeed gap flattens
  // to a couple of m/s, which is aerodynamics, not a missing burner.
  // MEASURED: 127.1 vs 114.6 m/s.
  {
    const arm = (burn) => {
      const v = spawn('jet');
      fly(v, { boost: 1 }, 8);             // identical prefix, lever firewalled
      fly(v, burn ? { boost: 1 } : {}, 4); // the ONLY difference: reheat
      return fwdSpeed(v);
    };
    const lit = arm(true);
    const dry = arm(false);
    check('jet', 'afterburner measurably adds thrust (emitted speed, matched arms)',
      lit > dry + 7,
      `burner ${lit.toFixed(1)} m/s vs dry ${dry.toFixed(1)} m/s after the same 12 s`);
  }

  /* ---- NEGATIVE CONTROL: no throttle, no take-off --------------------- */
  {
    const v = spawn('jet');
    fly(v, {}, 26);
    check('jet', 'NEGATIVE CONTROL — no throttle, it never leaves the runway',
      fwdSpeed(v) < 2 && v.altitude < 0.2 && v.grounded >= 3,
      `airspeed ${fwdSpeed(v).toFixed(2)} m/s, altitude ${v.altitude.toFixed(3)} m, ${v.grounded} wheels down`);
  }

  /* ---- NEGATIVE CONTROL: sportplane thrust fails the margin ----------- */
  {
    const ctrl = spawnSpec(variantSpec('jet', (b) => {
      b.flight = {
        ...b.flight,
        maxThrust: VEHICLE_SPECS.sportplane.flight.maxThrust,
        propVmax: VEHICLE_SPECS.sportplane.flight.propVmax,
        afterburner: null,
      };
    }));
    fly(ctrl, { boost: 1 }, 26);
    check('jet', 'NEGATIVE CONTROL — sportplane thrust under this airframe fails the speed margin',
      fwdSpeed(ctrl) < vSport + 5 && ctrl.grounded >= 3 && ctrl.altitude < 0.5,
      `control ${fwdSpeed(ctrl).toFixed(1)} m/s, altitude ${ctrl.altitude.toFixed(2)} m (the jet did ${vJet.toFixed(1)})`);
  }
}

/* ================================================================== */
/* 5. SILHOUETTES AND LIVERIES — the variants READ different          */
/* ================================================================== */
/**
 * All measured on the geometry the builders EMIT — the same vertices build.js
 * merges into the meshes on screen — never on the style block that asked for
 * them (rule 12: the input is not the measurement).
 */
function paintExtent(out, groups = ['paint']) {
  let minZ = Infinity, maxZ = -Infinity, maxX = 0;
  for (const g of groups) {
    for (const geo of out[g] ?? []) {
      const p = geo.attributes.position;
      for (let i = 0; i < p.count; i++) {
        const z = p.getZ(i);
        if (z < minZ) minZ = z;
        if (z > maxZ) maxZ = z;
        const x = Math.abs(p.getX(i));
        if (x > maxX) maxX = x;
      }
    }
  }
  return { len: maxZ - minZ, maxX };
}
/** Mean emitted y of everything further outboard than `xMin` — the wing band.
 *  Only the main wing lives out there (the stabs stop well inside 2.6 m). */
function wingBandY(out, xMin = 2.6) {
  let sum = 0, n = 0;
  for (const geo of out.paint ?? []) {
    const p = geo.attributes.position;
    for (let i = 0; i < p.count; i++) {
      if (Math.abs(p.getX(i)) > xMin) { sum += p.getY(i); n++; }
    }
  }
  return n ? sum / n : NaN;
}
function rotorRadius(out) {
  let r = 0;
  const p = out.rotors[0].geo.attributes.position;
  for (let i = 0; i < p.count; i++) {
    const d = Math.hypot(p.getX(i), p.getZ(i));
    if (d > r) r = d;
  }
  return r;
}

function testSilhouettes() {
  const heli = buildHeliBody(finalizeSpec(VEHICLE_SPECS.heli), 0);
  const news = buildHeliBody(finalizeSpec(VEHICLE_SPECS.newsheli), 0);
  const lark = buildPlaneBody(finalizeSpec(VEHICLE_SPECS.plane), 0);
  const sportSpec = finalizeSpec(VEHICLE_SPECS.sportplane);
  const sport = buildPlaneBody(sportSpec, 0);

  // Helicopters: the news machine is visibly longer with a bigger disc.
  const he = paintExtent(heli), ne = paintExtent(news);
  check('silhouette', 'the Skywatch is over a metre longer than the Riverhop',
    ne.len > he.len + 0.9,
    `${ne.len.toFixed(2)} m vs ${he.len.toFixed(2)} m emitted fuselage length`);
  const hr = rotorRadius(heli), nr = rotorRadius(news);
  check('silhouette', 'the Skywatch swings a bigger rotor disc',
    nr > hr + 0.3, `${nr.toFixed(2)} m vs ${hr.toFixed(2)} m emitted blade reach`);

  // Planes: high wing vs low wing, and a much shorter span.
  const fyL = VEHICLE_SPECS.plane.style.fuseY;
  const fyS = VEHICLE_SPECS.sportplane.style.fuseY;
  const wL = wingBandY(lark), wS = wingBandY(sport);
  check('silhouette', 'the Skylark carries its wing HIGH over the fuselage centreline',
    wL > fyL + 0.5, `wing band y ${wL.toFixed(2)} vs centreline ${fyL.toFixed(2)}`);
  check('silhouette', 'the Slipstream carries its wing LOW, under the centreline',
    wS < fyS, `wing band y ${wS.toFixed(2)} vs centreline ${fyS.toFixed(2)}`);
  check('silhouette', 'the two wings sit more than 0.8 m apart in the emitted metal',
    wL - wS > 0.8, `${wL.toFixed(2)} vs ${wS.toFixed(2)}`);
  const le = paintExtent(lark), se = paintExtent(sport);
  check('silhouette', 'the Slipstream span is over a metre shorter',
    le.maxX > se.maxX + 1.0, `half-span ${le.maxX.toFixed(2)} m vs ${se.maxX.toFixed(2)} m`);

  // NEGATIVE CONTROL: rebuild the Slipstream with the Skylark's wing height —
  // the low-wing reading must vanish, or the checks above are reading the id.
  const ctrl = buildPlaneBody(variantSpec('sportplane', (b) => {
    b.style.wingY = VEHICLE_SPECS.plane.style.wingY;
  }), 0);
  const wC = wingBandY(ctrl);
  check('silhouette', 'NEGATIVE CONTROL — with the Skylark wing height it reads high-wing',
    wC > fyS + 0.5, `control wing band y ${wC.toFixed(2)} vs centreline ${fyS.toFixed(2)}`);

  /* ---- the fighter: twin tails, hard sweep, a nozzle ------------------ */
  // All read off the emitted vertices, never the style block that asked.
  const jetSpec = finalizeSpec(VEHICLE_SPECS.jet);
  const jet = buildJetBody(jetSpec, 0);

  /** Fin population in a tail band: verts up high, well aft. */
  const tails = (out, yMin, zMax) => {
    let port = 0;
    let stbd = 0;
    let centre = 0;
    for (const geo of out.paint ?? []) {
      const p = geo.attributes.position;
      for (let i = 0; i < p.count; i++) {
        if (p.getY(i) < yMin || p.getZ(i) > zMax) continue;
        const x = p.getX(i);
        if (x > 0.3) stbd++;
        else if (x < -0.3) port++;
        else if (Math.abs(x) < 0.15) centre++;
      }
    }
    return { port, stbd, centre };
  };
  const jt = tails(jet, 2.6, -4.0);
  const st2 = tails(sport, 2.0, -2.4);
  check('silhouette', 'the jet carries TWIN tails, canted off the centreline',
    jt.port > 8 && jt.stbd > 8 && jt.centre === 0,
    `tail-band verts port ${jt.port} / stbd ${jt.stbd} / centre ${jt.centre}`);
  check('silhouette', 'the sportplane keeps its single centre fin (the contrast)',
    st2.centre > 8 && st2.port === 0 && st2.stbd === 0,
    `port ${st2.port} / stbd ${st2.stbd} / centre ${st2.centre}`);
  // NEGATIVE CONTROL: fold the fins onto the centreline and the twin-tail
  // reading must vanish — the detector measures metal, not the class id.
  const oneTail = tails(buildJetBody(variantSpec('jet', (b) => {
    b.style.finX = 0;
    b.style.finCant = 0;
  }), 0), 2.6, -4.0);
  check('silhouette', 'NEGATIVE CONTROL — fins folded to centre read single-tail',
    oneTail.centre > 8 && oneTail.port === 0 && oneTail.stbd === 0,
    `port ${oneTail.port} / stbd ${oneTail.stbd} / centre ${oneTail.centre}`);

  /** Leading-edge sweep: emitted max z at the wing root band vs at the tip. */
  const sweepOf = (out, spec2) => {
    const half = spec2.style.wingSpan * 0.5;
    const fuseHw = spec2.style.fuseR ?? 0.6;
    let root = -Infinity;
    let tip = -Infinity;
    for (const geo of out.paint ?? []) {
      const p = geo.attributes.position;
      for (let i = 0; i < p.count; i++) {
        const ax = Math.abs(p.getX(i));
        const z = p.getZ(i);
        if (z < spec2.style.wingZ - spec2.style.wingChord) continue; // wings only, not stabs
        if (ax > fuseHw + 0.25 && ax < fuseHw + 0.7 && z > root) root = z;
        if (ax > half * 0.92 && z > tip) tip = z;
      }
    }
    return root - tip;
  };
  const jSweep = sweepOf(jet, jetSpec);
  const sSweep = sweepOf(sport, sportSpec);
  check('silhouette', 'the delta wing is swept HARD against the sport plane\'s',
    jSweep > sSweep + 1.0,
    `leading edge falls back ${jSweep.toFixed(2)} m root->tip vs ${sSweep.toFixed(2)} m`);

  // The reheat can: emitted metal aft of the fuselage, around the tail axis.
  let nozzle = 0;
  for (const geo of jet.trim ?? []) {
    const p = geo.attributes.position;
    for (let i = 0; i < p.count; i++) {
      if (p.getZ(i) < jetSpec.style.fuseZ0 - 0.2 &&
          Math.abs(p.getY(i) - jetSpec.style.fuseY) < 0.8) nozzle++;
    }
  }
  check('silhouette', 'an afterburner nozzle hangs off the tail',
    nozzle > 12, `${nozzle} emitted nozzle verts aft of the fuselage`);

  /**
   * LIVERIES. Each variant's paint pools resolve through the SAME `PAINTS`
   * table the spawner reads (`_choosePaint`: `spec.paints` -> `PAINTS[pool]`),
   * and each variant's colour set shares nothing with its sibling's — so the
   * pair can never roll the same coat of paint.
   */
  const colours = (id) => {
    const out = new Set();
    for (const pool of VEHICLE_SPECS[id].paints ?? []) {
      for (const p of PAINTS[pool] ?? []) out.add(p.color);
    }
    return out;
  };
  for (const [a, b] of [['heli', 'newsheli'], ['plane', 'sportplane'], ['sportplane', 'jet']]) {
    const ca = colours(a), cb = colours(b);
    const overlap = [...cb].filter((c) => ca.has(c));
    check('livery', `${b} resolves its own paint pool (${VEHICLE_SPECS[b].paints.join(',')})`,
      cb.size > 0, `${cb.size} colours`);
    check('livery', `${b} shares no colour with ${a}`,
      cb.size > 0 && overlap.length === 0,
      overlap.length ? `shared: ${overlap.map((c) => c.toString(16)).join(',')}` : `${ca.size} vs ${cb.size} colours, disjoint`);
  }
}

/* ================================================================== */
/* 6. THE ENVELOPE — the speed the player actually feels              */
/* ================================================================== */
/**
 * ────────────────────────────────────────────────────────────────────────────
 * WHY A FLOOR ON A NUMBER NOBODY WAS ASSERTING
 * ────────────────────────────────────────────────────────────────────────────
 * Everything above this point gates that a machine flies AT ALL — it climbs,
 * it unsticks, it banks, it breaks when it arrives too fast. Not one assertion
 * in it would move if a helicopter's transit speed halved, and a player does
 * not experience "it climbs" — he experiences how long the Ohio takes to
 * cross. That is the shape of the report this section exists for: the
 * helicopter reported as "not moving forward as fast, making it hard to fly",
 * against a suite that was green through the whole of it.
 *
 * So the transit is measured and floored, on the emitted speed along the nose
 * and the emitted time to gain 100 m, at the values MEASURED on the flight
 * models as they stand:
 *
 *      dash, 30 s of full collective + full forward cyclic from the pad
 *        Riverhop        40.52 m/s top,  13.15 s to +100 m
 *        Skywatch 6      38.43 m/s top,  10.79 s to +100 m
 *      nap of the earth, levelled off low, then 20 s of full cyclic
 *        Riverhop        36.31 m/s top, undamaged
 *        Skywatch 6      34.88 m/s top, undamaged
 *      fixed-wing, 40 s of throttle with the elevator in once rolling
 *        Skylark         44.55 m/s top,   7.64 m/s best climb
 *        Slipstream      69.20 m/s top,  15.48 m/s best climb
 *        jet            115.26 m/s top,  82.93 m/s best climb
 *
 * The bands are 3%, which is wider than this model's run-to-run spread (it has
 * none — the integrator is deterministic and every figure above reproduces to
 * the last digit) and narrow enough that no loss a player could feel fits
 * inside one.
 *
 * ────────────────────────────────────────────────────────────────────────────
 * AND THE A/B THAT SAYS THE ROLLOVER WORK CANNOT REACH A FLIGHT MODEL
 * ────────────────────────────────────────────────────────────────────────────
 * `_rollAssist`, `_rightSelf` and the contact-normal yaw axis all landed in
 * `dynamics.js`, which every kind shares, and all three are the natural
 * suspects for a rotorcraft that lost speed. Reading the guards is not
 * evidence; flying the identical profile with all three DISARMED on the live
 * vehicle is. `debugNoRollAssist` / `debugNoRight` / `debugBodyYaw` exist for
 * exactly that (ARCHITECTURE rule 12), and the claim asserted here is the
 * strong one — not "close enough" but the SAME EMITTED TRAJECTORY, to 1e-9 —
 * because anything less would leave room for a small bleed to hide in.
 *
 * A rotorcraft must also never take the fixed-wing probe ring: the fuselage
 * capsule and the swept `_airSweep` belong to `kind: 'plane'`, and a helicopter
 * that grew a 0.6 m sphere on its centreline would drag it through the deck in
 * exactly this profile. Asserted on the RING THE VEHICLE BUILT, not on the kind
 * string that chose it.
 */
/** All three roll/righting hooks off, for the inertness A/B. */
const NO_ASSIST = { debugNoRollAssist: true, debugNoRight: true, debugBodyYaw: true };
/** Scratch input for the closed-loop profiles below (hard rule 5). */
const _in = { throttle: 0, brake: 0, steer: 0, handbrake: false, boost: 0 };

/** 30 s of full collective and full forward cyclic, from rest on the pad. */
function dash(v, seconds = 30) {
  const y0 = v.position.y;
  let top = 0;
  let t100 = Infinity;
  _in.throttle = 1; _in.brake = 0; _in.steer = 0; _in.handbrake = true; _in.boost = 0;
  fly(v, _in, seconds, (m, i) => {
    const s = fwdSpeed(m);
    if (s > top) top = s;
    if (t100 === Infinity && m.position.y - y0 >= 100) t100 = (i + 1) / 120;
  });
  return { top, t100 };
}

/**
 * Level off low, then push the cyclic and hold it — the profile a player flies
 * down a river, and the one where a ground contact priced as an impact, or a
 * probe sphere dragging through the deck, would show up as lost speed. The
 * collective is closed-loop on the EMITTED altitude, so both machines settle at
 * their own hover height rather than at a number written here.
 */
function nap(v, seconds = 20, hold = 3) {
  const health0 = v.health;
  fly(v, { }, 6);                                    // spool, skids on the deck
  fly(v, (m) => {
    _in.throttle = 0; _in.brake = 0; _in.steer = 0; _in.boost = 0;
    _in.handbrake = m.altitude < hold;
    return _in;
  }, 6);
  let top = 0;
  let minAlt = Infinity;
  fly(v, (m) => {
    _in.throttle = 1; _in.brake = 0; _in.steer = 0; _in.boost = 0;
    _in.handbrake = m.altitude < hold;
    return _in;
  }, seconds, (m) => {
    const s = fwdSpeed(m);
    if (s > top) top = s;
    if (m.altitude < minAlt) minAlt = m.altitude;
  });
  return { top, minAlt, lost: health0 - v.health, destroyed: v.destroyed };
}

/** Full throttle down the runway and away, elevator in once it is rolling. */
function climbOut(v, seconds = 40) {
  let top = 0;
  let climb = 0;
  fly(v, (m) => {
    _in.throttle = 0; _in.steer = 0; _in.handbrake = false; _in.boost = 1;
    _in.brake = fwdSpeed(m) > 32 ? 0.45 : 0;
    return _in;
  }, seconds, (m) => {
    const s = fwdSpeed(m);
    if (s > top) top = s;
    if (m.velocity.y > climb) climb = m.velocity.y;
  });
  return { top, climb };
}

function testEnvelope() {
  /* ---- the transit: a floor on speed and a ceiling on time ----------- */
  for (const [id, name, topMin, t100Max] of [
    ['heli', 'Riverhop', 39.31, 13.54],
    ['newsheli', 'Skywatch 6', 37.28, 11.12],
  ]) {
    const r = dash(spawn(id));
    check('envelope', `${name} holds its transit speed under full cyclic`,
      r.top >= topMin,
      `${r.top.toFixed(2)} m/s top, floor ${topMin} (measured ${id === 'heli' ? 40.52 : 38.43})`);
    check('envelope', `${name} still reaches 100 m in the time it always did`,
      r.t100 <= t100Max,
      `${r.t100.toFixed(2)} s to +100 m, ceiling ${t100Max}`);
  }

  /* ---- low and fast: no contact of a rotorcraft's may cost it ------- */
  for (const [id, name, topMin] of [
    ['heli', 'Riverhop', 35.22],
    ['newsheli', 'Skywatch 6', 33.83],
  ]) {
    const r = nap(spawn(id));
    check('envelope', `${name} holds its speed nap-of-the-earth`,
      r.top >= topMin,
      `${r.top.toFixed(2)} m/s top at ${r.minAlt.toFixed(2)} m AGL, floor ${topMin}`);
    check('envelope', `${name} takes no damage from twenty seconds down there`,
      r.lost === 0 && r.destroyed === false,
      `lost ${r.lost} health, destroyed ${r.destroyed}`);
  }

  /* ---- the fixed-wing fleet did not go with it ---------------------- */
  for (const [id, name, topMin, climbMin] of [
    ['plane', 'Skylark', 43.22, 7.41],
    ['sportplane', 'Slipstream', 67.12, 15.01],
    ['jet', 'the jet', 111.81, 80.44],
  ]) {
    const r = climbOut(spawn(id));
    check('envelope', `${name} holds its top speed`, r.top >= topMin,
      `${r.top.toFixed(2)} m/s, floor ${topMin}`);
    check('envelope', `${name} holds its climb rate`, r.climb >= climbMin,
      `${r.climb.toFixed(2)} m/s best climb, floor ${climbMin}`);
  }

  /* ---- A/B: the roll/righting work is inert on an aircraft ---------- */
  for (const id of AIRCRAFT) {
    const heli = VEHICLE_SPECS[id].kind === 'heli';
    const run = (hooks) => {
      const v = spawn(id);
      if (hooks) Object.assign(v, hooks);
      const r = heli ? dash(v, 20) : climbOut(v, 20);
      return { ...r, x: v.position.x, y: v.position.y, z: v.position.z };
    };
    const a = run(null);
    const b = run(NO_ASSIST);
    const d = Math.max(
      Math.abs(a.top - b.top), Math.abs(a.x - b.x), Math.abs(a.y - b.y), Math.abs(a.z - b.z)
    );
    check('envelope', `${id} flies identically with the roll assists disarmed`,
      d < 1e-9,
      `top ${a.top.toFixed(4)} vs ${b.top.toFixed(4)} m/s, worst delta ${d.toExponential(2)}`);
  }

  /* ---- no rotorcraft may take the fixed-wing probe ring -------------- */
  for (const id of AIRCRAFT) {
    const v = spawn(id);
    const plane = v.spec.kind === 'plane';
    // The generic corner ring is what the constructor builds for everything
    // that is not `kind: 'plane'`, and it is bounded at 0.32 m — a fuselage
    // capsule on a helicopter's centreline would be twice that.
    const ok = plane
      ? !!v._fuseA && v.probeR > 0.4
      : v._fuseA === undefined && v.probeR <= 0.32;
    check('envelope', `${id} carries the ${plane ? 'fuselage' : 'corner'} probe ring`, ok,
      `kind ${v.spec.kind}, ${v.probes.length} probes at r ${v.probeR.toFixed(3)}, fuselage capsule ${v._fuseA ? 'yes' : 'no'}`);
  }

  /* ---- NEGATIVE CONTROLS: the floors above are load-bearing ---------- */
  /**
   * Three ways a shared-code change could plausibly cost the machine its
   * transit — more drag on the disc, less cyclic authority, less collective —
   * each applied to the spec and each required to drive the assertion RED. A
   * floor that nothing can fail is a comment.
   */
  for (const [label, mutate, red] of [
    ['three times the disc drag', (b) => { b.rotor.discDrag *= 3; }, 'top'],
    ['a third of the cyclic authority', (b) => { b.rotor.pitchMax /= 3; }, 'top'],
    ['half the commanded climb', (b) => { b.rotor.climbUp /= 2; }, 't100'],
  ]) {
    const r = dash(spawnSpec(variantSpec('heli', mutate)));
    const fell = red === 'top' ? r.top < 39.31 : r.t100 > 13.54;
    check('envelope', `NEGATIVE CONTROL — with ${label} the floor fails`, fell,
      `${r.top.toFixed(2)} m/s top, ${r.t100.toFixed(2)} s to +100 m`);
  }
}

/* ================================================================== */
testEnter();
testHeli();
testPlane();
testArrival();
testNewsHeli();
testSportPlane();
testJet();
testSilhouettes();
testEnvelope();

console.log(`\nflightprobe: ${pass}/${pass + fail} checks passed`);
if (fail) {
  console.log('FAILURES:');
  for (const f of fails) console.log('  - ' + f);
  process.exit(1);
}
