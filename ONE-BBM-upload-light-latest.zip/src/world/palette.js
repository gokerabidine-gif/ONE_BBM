/**
 * WORLD — the surface palette.
 *
 * A named set of material variants pulled from the `materials` library. Keeping
 * them in one table means the level uses a deliberate, limited palette (which is
 * what makes a real map read as one place) and that every mesh sharing a key
 * merges into the same draw call.
 *
 * `surface` is the ARCHITECTURE.md physics/FX tag. `tint` is a linear multiply
 * on the baked albedo, so values stay inside 0.02–0.9 reflectance.
 */
export const PALETTE = {
  // ---------------------------------------------------------- architecture --
  plaster_cream: {
    name: 'plaster',
    surface: 'plaster',
    opts: { vertexMasks: true, tint: 0xcfc0a4, scale: 2.35, weather: [0.4, 0.5, 1.4, 0.55] },
  },
  plaster_sand: {
    name: 'plaster',
    surface: 'plaster',
    opts: { vertexMasks: true, tint: 0xb9a582, scale: 2.1, weather: [0.45, 0.5, 1.5, 0.6] },
  },
  plaster_blue: {
    name: 'plaster',
    surface: 'plaster',
    opts: { vertexMasks: true, tint: 0x8f9aa0, scale: 2.2, weather: [0.4, 0.55, 1.5, 0.6] },
  },
  plaster_pink: {
    name: 'plaster',
    surface: 'plaster',
    opts: { vertexMasks: true, tint: 0xc09a86, scale: 2.5, weather: [0.45, 0.5, 1.3, 0.55] },
  },
  plaster_white: {
    name: 'plaster',
    surface: 'plaster',
    opts: { vertexMasks: true, tint: 0xd8d2c4, scale: 1.9, weather: [0.3, 0.35, 0.9, 0.5] },
  },
  brick: {
    name: 'brick',
    surface: 'concrete',
    opts: { vertexMasks: true, tint: 0xa8846c, scale: 1.3 },
  },
  /** Hollow clay block exposed where the render has spalled off. */
  brick_fine: {
    name: 'brick',
    surface: 'concrete',
    opts: { vertexMasks: true, tint: 0x9c8068, scale: 0.62, weather: [0.45, 0.5, 0.8, 0.6] },
  },
  concrete: {
    name: 'concrete',
    surface: 'concrete',
    opts: { vertexMasks: true, tint: 0xa9a49a, scale: 2.5 },
  },
  /**
   * Prop-scale concrete. A 2.5 m texture tile across a 0.5 m block shows a
   * single smear of noise and reads as untextured plastic; small objects need
   * their own, much tighter tiling.
   */
  concrete_prop: {
    name: 'concrete',
    surface: 'concrete',
    opts: {
      vertexMasks: true,
      tint: 0xa5a096,
      scale: 0.9,
      normalStrength: 1.3,
      weather: [0.45, 0.5, 0.35, 0.55],
    },
  },
  concrete_dark: {
    name: 'concrete',
    surface: 'concrete',
    opts: { vertexMasks: true, tint: 0x7d7a73, scale: 2.2, weather: [0.4, 0.6, 1.2, 0.6] },
  },
  /** Roof screed: flat, sand-dusted, and the biggest surface in any skyline. */
  roof_screed: {
    name: 'concrete',
    surface: 'concrete',
    opts: { vertexMasks: true, tint: 0xb5a992, scale: 2.8, weather: [0.6, 0.2, 0.3, 0.45] },
  },
  floor_concrete: {
    name: 'concrete_floor',
    surface: 'concrete',
    opts: { vertexMasks: true, tint: 0x9e9a91, scale: 3.0 },
  },
  tile_floor: {
    name: 'tile',
    surface: 'concrete',
    opts: { vertexMasks: true, tint: 0xa9a08d, scale: 1.4 },
  },

  // ----------------------------------------------------------------- ground --
  /**
   * The street itself. A black tarmac road makes a sunlit Levantine town read
   * as a wet European city at dusk — the actual surface is old tarmac buried
   * under years of blown sand and dust, so the base is warm compacted earth and
   * the asphalt only shows through where wheels have polished it.
   */
  road_dust: {
    name: 'gravel',
    surface: 'dirt',
    opts: {
      vertexMasks: true,
      tint: 0xc9b896,
      // 2.2 m, not 1.5: the aggregate reads as 25-45 mm stone instead of a
      // 15 mm rash, and the macro relief band lands on ruts rather than on
      // individual pebbles.
      scale: 2.2,
      // de-tile: a repeating cracked-earth tile down a 100 m street is the most
      // obvious tell in any procedural level.
      detile: 0.9,
      // .w is cavity grime. On gravel the height field IS the aggregate, so
      // this darkens every interstice: at 0.4 the road histogram was bimodal
      // (mass at 32-80 and 144-176 with a hollow middle) — dither, not surface.
      weather: [0.4, 0.04, 0.08, 0.14],
      // No edge wear on a road. The vertex wear mask exists to rub through the
      // arris of a prop; on a 100 m plane it just brightens every stone crown.
      wear: [0, 0.5, 0.45, 0],
    },
  },
  asphalt: {
    name: 'asphalt',
    surface: 'concrete',
    opts: { vertexMasks: true, tint: 0x9d968a, scale: 3.2, detile: 0.6, wear: [0, 0.55, 0.45, 0] },
  },
  /**
   * The driving line: tarmac polished bare by tyres and stained with oil. A
   * clear stop darker than `road_dust`, because a rut the same value as the dust
   * around it is invisible and the road goes back to being one flat plane.
   */
  road_rut: {
    name: 'asphalt',
    surface: 'concrete',
    opts: {
      vertexMasks: true,
      tint: 0x6f6a62,
      scale: 1.5,
      detile: 0.7,
      weather: [0.3, 0.5, 0.15, 0.28],
      wear: [0, 0.55, 0.45, 0],
    },
  },
  sand: {
    name: 'sand',
    surface: 'sand',
    opts: { vertexMasks: true, scale: 2.6, detile: 0.7, wear: [0, 0.45, 0.45, 0] },
  },
  dirt: {
    name: 'dirt',
    surface: 'dirt',
    opts: { vertexMasks: true, scale: 2.4, detile: 0.8, wear: [0, 0.5, 0.45, 0] },
  },
  gravel: {
    name: 'gravel',
    surface: 'dirt',
    opts: { vertexMasks: true, scale: 1.8, wear: [0, 0.5, 0.45, 0] },
  },
  /**
   * The contact fillet swept up against anything standing on the ground (see
   * Assembler.put / props.dustSkirt). It has to read as the ground's own grit
   * piled up, so it is the same generator as the road at a slightly darker,
   * greyer tint, with the grime mask doing the work at the contact line. The
   * first attempt used `dirt`, which is a stop lighter and carries mud cracks:
   * every prop got a pale polygonal plate around it.
   */
  dust_skirt: {
    name: 'gravel',
    surface: 'dirt',
    opts: {
      vertexMasks: true,
      tint: 0xa89d86,
      scale: 1.1,
      weather: [0.3, 0.0, 0.0, 0.16],
      wear: [0, 0.9, 0.7, 0],
    },
  },

  // ------------------------------------------------------------------ metal --
  metal_rust: { name: 'metal_rust', surface: 'metal', opts: { vertexMasks: true, scale: 1.1 } },
  /**
   * Prop-scale rust. A 1.1 m tile wrapped round a 0.6 m oil drum shows one smear
   * of noise and the drum reads as pink plastic — the same trap as
   * `concrete_prop` / `wood_prop`. Drums and buckets are eye-level silhouette
   * breakers in the mid-ground, so they need tiling that resolves at 3 m.
   */
  metal_rust_prop: {
    name: 'metal_rust',
    surface: 'metal',
    opts: {
      vertexMasks: true,
      tint: 0x9d7c66,
      scale: 0.4,
      normalStrength: 1.35,
      weather: [0.5, 0.35, 0.3, 0.5],
    },
  },
  metal_blue: {
    name: 'metal_painted',
    surface: 'metal',
    opts: { vertexMasks: true, tint: 0x6d8390, scale: 1.3 },
  },
  metal_green: {
    name: 'metal_painted',
    surface: 'metal',
    opts: { vertexMasks: true, tint: 0x76806a, scale: 1.3 },
  },
  metal_dark: {
    name: 'metal_painted',
    surface: 'metal',
    opts: { vertexMasks: true, tint: 0x4a4a48, scale: 1.0 },
  },
  steel: { name: 'metal_brushed', surface: 'metal', opts: { vertexMasks: true, scale: 0.9 } },
  corrugated: { name: 'corrugated', surface: 'metal', opts: { vertexMasks: true, scale: 2.2 } },

  // ---------------------------------------------------------------- organic --
  wood: { name: 'wood', surface: 'wood', opts: { vertexMasks: true, scale: 1.8 } },
  /**
   * Prop-scale timber. A 1.8 m grain tile across a 0.5 m crate slat shows one
   * soft smear; crates, pallets, planks and stall tables need ~0.5 m tiling
   * before the grain, the saw marks and the dirt in the joints read at all.
   */
  wood_prop: {
    name: 'wood',
    surface: 'wood',
    opts: {
      vertexMasks: true,
      tint: 0xb08a5e,
      scale: 0.55,
      normalStrength: 1.45,
      weather: [0.35, 0.3, 0.35, 0.5],
    },
  },
  wood_prop_dark: {
    name: 'wood',
    surface: 'wood',
    opts: {
      vertexMasks: true,
      tint: 0x7d6244,
      scale: 0.5,
      normalStrength: 1.45,
      weather: [0.35, 0.35, 0.4, 0.55],
    },
  },
  wood_dark: {
    name: 'wood',
    surface: 'wood',
    opts: { vertexMasks: true, tint: 0x8a6a4a, scale: 1.5 },
  },
  wood_pale: {
    name: 'wood',
    surface: 'wood',
    opts: { vertexMasks: true, tint: 0xc0a482, scale: 1.2 },
  },
  fabric_red: {
    name: 'fabric',
    surface: 'fabric',
    opts: { vertexMasks: true, tint: 0xa2564a, scale: 0.26, three: { side: 2 } },
  },
  fabric_teal: {
    name: 'fabric',
    surface: 'fabric',
    opts: { vertexMasks: true, tint: 0x5f8a8c, scale: 0.26, three: { side: 2 } },
  },
  fabric_cream: {
    name: 'fabric',
    surface: 'fabric',
    opts: { vertexMasks: true, tint: 0xbcb298, scale: 0.26, three: { side: 2 } },
  },
  /**
   * Hessian. The weave has to be fine — a 0.5 m tile turns every sandbag into a
   * picnic basket, and sandbags are the most-repeated prop in the level.
   *
   * The tint is deliberately well under a bright sand value: an emplacement is
   * dozens of square metres of one material low in the frame, and at the old
   * value it was the brightest thing in the bottom two thirds of the night shot
   * with nothing lighting it. Filled hessian is a mid-tone — 0.18-0.24 linear —
   * darker than the plaster behind it and darker than the dust it sits on.
   */
  burlap: {
    name: 'burlap',
    surface: 'fabric',
    opts: { vertexMasks: true, tint: 0xa2957a, scale: 0.16, weather: [0.5, 0.3, 0.4, 0.5] },
  },
  rubber: { name: 'rubber', surface: 'rubber', opts: { vertexMasks: true, scale: 0.45 } },
  glass: { name: 'glass', surface: 'glass', opts: { scale: 2.0 } },
  foliage: { name: 'foliage', surface: 'foliage', opts: { vertexMasks: true } },

  // ------------------------------------------------------------- apertures --
  /**
   * The dark core BEHIND a window opening. A window is not a grey rectangle: it
   * is a hole with a dark room behind it, and the only thing that sells it is a
   * genuinely dark backing plane set 15-25 cm back from the glass so the reveal
   * casts onto it and the opening parallaxes as the camera moves. Final linear
   * albedo lands around 0.03 (the tint is a linear multiply on the baked
   * plaster albedo), which is the reflectance of an unlit room seen from a
   * sunlit street — dark, but still carrying plaster texture rather than being
   * a black hole.
   */
  window_void: {
    name: 'plaster',
    surface: 'plaster',
    opts: {
      vertexMasks: true,
      tint: 0x474441,
      scale: 1.1,
      roughness: [1.0, 0.15],
      weather: [0.2, 0.7, 0.2, 0.7],
    },
  },
  /**
   * The dark shell inside a non-enterable building. Seen through doorways and
   * blown-out holes as well as windows, so it sits a stop above `window_void`:
   * dark, readable, never a white blank.
   */
  interior_shell: {
    name: 'plaster',
    surface: 'plaster',
    opts: {
      vertexMasks: true,
      tint: 0x5f5b56,
      scale: 1.6,
      roughness: [1.0, 0.1],
      weather: [0.25, 0.8, 0.3, 0.65],
    },
  },
  /**
   * Window glass. Distinct from the `glass` used on bottles and shards purely
   * so the roughness can be forced down: below 0.62 the render's SSR/IBL path
   * kicks in and the pane picks up the sky, which is what stops a window
   * reading as taped-over paper.
   */
  window_glass: {
    name: 'glass',
    surface: 'glass',
    opts: {
      scale: 2.0,
      roughness: [0.3, 0.06],
      three: { opacity: 0.16, envMapIntensity: 2.1 },
    },
  },
  /** Plywood sheet nailed over a broken window. */
  plywood: {
    name: 'wood',
    surface: 'wood',
    opts: {
      vertexMasks: true,
      tint: 0x7a6549,
      scale: 0.62,
      normalStrength: 1.2,
      weather: [0.5, 0.45, 0.5, 0.6],
    },
  },

  // ---------------------------------------------------------------- emissive --
  /** Bare interior bulb. Tiny surface, so it needs real radiance to read. */
  emissive_warm: {
    name: 'plaster',
    surface: 'glass',
    opts: {
      scale: 0.4,
      tint: 0xfff0d8,
      three: { emissive: 0xffd39a, emissiveIntensity: 12, toneMapped: true },
    },
  },
  /**
   * A lit room seen from the street. Much dimmer than `emissive_warm`: this is a
   * whole wall of a room catching a bulb, not the bulb itself, and at daylight
   * exposure it only has to lift the opening off the dark-core value.
   */
  window_glow: {
    name: 'plaster',
    surface: 'plaster',
    opts: {
      vertexMasks: true,
      tint: 0x6a5a45,
      scale: 1.2,
      three: { emissive: 0xffb066, emissiveIntensity: 1.1, toneMapped: true },
    },
  },
  /** Street-lamp diffuser. Emission is driven by time of day at runtime. */
  lamp_lens: {
    name: 'glass',
    surface: 'glass',
    opts: {
      scale: 1.0,
      three: { emissive: 0xffc47a, emissiveIntensity: 0, opacity: 0.5 },
    },
  },

  /* ==================================================================== */
  /* STEEL CITY — the open-world surfaces                                 */
  /*                                                                      */
  /* These are thin aliases onto the road/nature families `materials`      */
  /* provides for the open world. Nothing here re-authors a surface —      */
  /* the palette's job is to name the small, deliberate set Steel City is  */
  /* allowed to use, so every mesh sharing a key merges into one draw.     */
  /* ==================================================================== */

  /**
   * The carriageway on a straight. LANE-ALIGNED: the mesh carries u across the
   * road and v along it, so the surface's wheel-polish bands, the oil line down
   * the lane centre and the paver's cold joint all land where traffic actually
   * put them. `roadmesh` maps 1 uv unit = 4 m, which is what the library asks
   * for. This is the single biggest signal on a road that a stretched grey
   * plane does not have.
   */
  road: { name: 'road_lane', surface: 'asphalt', opts: { tint: 0x6b6b68 } },
  /** Junction pads: no lane direction exists there, so world projection. */
  road_pad: { name: 'road_asphalt', surface: 'asphalt', opts: { tint: 0x6b6b68 } },
  /** Back streets and mill approaches: cut, patched and cracked to pieces. */
  road_patch: { name: 'road_asphalt_patched', surface: 'asphalt', opts: { tint: 0x5c5c57 } },

  walk: { name: 'sidewalk', surface: 'sidewalk', opts: {} },
  walk_old: { name: 'sidewalk_old', surface: 'sidewalk', opts: {} },
  kerb: { name: 'kerb', surface: 'sidewalk', opts: {} },

  /**
   * Markings are alpha-masked decals whose glyph, wear and junction scrub are
   * all in the surface, so `roadmesh` emits ONE quad per line and the material
   * dashes it, thins it and rubs it through at the wheel line.
   */
  line_white: { name: 'road_line', surface: 'asphalt', opts: {} },
  line_dash: { name: 'road_line_dash', surface: 'asphalt', opts: {} },
  line_yellow: { name: 'road_line_double', surface: 'asphalt', opts: {} },
  mark_cross: { name: 'road_crossing', surface: 'asphalt', opts: {} },
  mark_stop: { name: 'road_stopbar', surface: 'asphalt', opts: {} },

  drain: { name: 'drain_grate', surface: 'metal', opts: {} },
  cover: { name: 'manhole', surface: 'metal', opts: {} },

  /* ---------------------------------------------------------- terrain --- */
  /** Valley floor and hillside. */
  terrain_grass: { name: 'grass', surface: 'grass', opts: { tint: 0xbfc6ac } },
  /** Flats, mill land, and everything the rain has churned. */
  terrain_dirt: { name: 'mud', surface: 'dirt', opts: {} },
  /** Anything steeper than ~32 degrees: the Mt. Washington face, cut banks. */
  terrain_rock: { name: 'gravel', surface: 'gravel', opts: { uvMode: 'triplanar', scale: 2.6, tint: 0x8b877e, macroRelief: 0.9 } },
  /** The river bank between the waterline and the top of the bank. */
  terrain_silt: { name: 'river_silt', surface: 'dirt', opts: {} },
  /** The strip between the back of the pavement and undisturbed ground. */
  verge: { name: 'grass_verge', surface: 'grass', opts: { tint: 0xbcc2a8 } },
  /**
   * The RISER of that strip.
   *
   * `netgen.rasteriseRoads` deliberately sinks the ground half a metre under
   * every corridor so it can never come up through the tarmac, and the kerb and
   * pavement stand another 15 cm above that. Behind an urban pavement the verge
   * therefore has 0.7 m to lose across less than a metre of ground — a face at
   * 40-70 degrees. Grass does not grow on a 70-degree face, and drawing it with
   * `grass_verge` is what a critic panel reported as "the kerb's vertical face
   * has grass on it". The step is a low retaining wall and it is poured
   * concrete, projected triplanar so a near-vertical band does not smear.
   */
  verge_riser: {
    name: 'concrete',
    surface: 'concrete',
    opts: { uvMode: 'triplanar', scale: 1.9, tint: 0x8e8a80, macroRelief: 0.45 },
  },

  /* ------------------------------------------------------------- rail --- */
  ballast: { name: 'gravel', surface: 'gravel', opts: { uvMode: 'triplanar', scale: 1.15, tint: 0x8b8478 } },
  rail_steel: { name: 'plate_steel', surface: 'metal', opts: { vertexMasks: true } },
  sleeper: {
    name: 'wood',
    surface: 'wood',
    opts: { vertexMasks: true, tint: 0x4e433a, scale: 0.55, weather: [0.35, 0.5, 1.2, 0.6] },
  },

  /* -------------------------------------------------------- airfields --- */
  /**
   * The runway strip. World-projected asphalt (no lane direction exists on a
   * runway), a touch lighter and greyer than the streets — weathered concrete-
   * asphalt that has sat out in the rain since the mills closed.
   */
  runway: { name: 'road_asphalt', surface: 'asphalt', opts: { tint: 0x767470 } },
  /** Apron and taxiways: poured concrete panels, triplanar like the risers. */
  apron_slab: {
    name: 'concrete',
    surface: 'concrete',
    opts: { uvMode: 'triplanar', scale: 2.3, tint: 0x8f8c85, macroRelief: 0.35 },
  },
  /** Threshold bars, centreline dashes and painted heading numbers. */
  runway_paint: {
    name: 'concrete',
    surface: 'asphalt',
    opts: { uvMode: 'triplanar', scale: 1.1, tint: 0xd9d5c6 },
  },
  /**
   * Ridgeline AFB paving. Darker and colder than the civilian strips: the
   * military pours fresh asphalt and grinds it grey, and the aprons are big
   * drab concrete panels. Warning paint is faded chromate yellow.
   */
  runway_mil: { name: 'road_asphalt', surface: 'asphalt', opts: { tint: 0x5e5f5c } },
  apron_mil: {
    name: 'concrete',
    surface: 'concrete',
    opts: { uvMode: 'triplanar', scale: 2.6, tint: 0x7f827b, macroRelief: 0.4 },
  },
  mil_paint_yellow: {
    name: 'concrete',
    surface: 'asphalt',
    opts: { uvMode: 'triplanar', scale: 1.1, tint: 0xc2a03a },
  },
  /** Runway edge / threshold lamps. Small boxes; real radiance so they read. */
  runway_lamp: {
    name: 'plaster',
    surface: 'glass',
    opts: {
      scale: 0.4,
      tint: 0xfff1cf,
      three: { emissive: 0xffd9a0, emissiveIntensity: 9, toneMapped: true },
    },
  },

  /* ---------------------------------------------------------- bridges --- */
  bridge_concrete: { name: 'precast', surface: 'concrete', opts: { vertexMasks: true } },
  /**
   * THE THREE BRIDGE PAINTS.
   *
   * Steel City paints its crossings the way Pittsburgh does: the sisters and
   * the gateway spans in the city's own gold, the long river crossings in cold
   * structural blue, and the mill's bridge in nothing at all. Which span wears
   * which is `plan.BRIDGES[].steel`; this table only says what the paint IS.
   *
   * ALL THREE RESOLVE ONTO ONE BAKE. `materials.get(name, opts)` keys its
   * TEXTURE on `name` and applies `tint` as a linear multiply on the finished
   * material, exactly as `plaster_cream` / `plaster_blue` / `plaster_pink` all
   * share one `plaster` bake. So three bridge colours cost three MATERIALS and
   * zero extra texture memory — the 1024x1024 `bridge_steel` bake is made
   * resident once either way. Tinting away from a bake instead of adding one
   * is the whole reason the palette is a table of variants.
   *
   * The tints are multiplies, so they are chosen against `bridge_steel`'s own
   * `tintA` of 0xc8a13c — a warm gold. `bridge_gold` is that colour left
   * alone; `bridge_blue` has to pull a long way off it, which is why its
   * multiply is heavy on blue and light on red.
   */
  /**
   * AZTEC GOLD. The bake's own `tintA` is 0xc8a13c, which comes out of the
   * forge as a WEATHERED gold — right for a hundred-year-old truss up close,
   * and, photographed at 300 m through this city's haze, indistinguishable
   * from the rust on the mill. The multiply below saturates it: `alb.rgb *=
   * tint` is a shader uniform (`materials/shader.js`, `owTintCol`) and is NOT
   * part of `_bakeKey`, so it costs one material and not one byte of texture.
   * Blue is what it takes out — 0x55/0xff = 0.33 — which is exactly what
   * separates gold from brown at distance.
   */
  bridge_gold: {
    name: 'bridge_steel',
    surface: 'metal',
    opts: { vertexMasks: true, tint: 0xffcf55 },
  },
  bridge_blue: {
    name: 'bridge_steel',
    surface: 'metal',
    opts: { vertexMasks: true, tint: 0x5c86b4 },
  },
  bridge_black: {
    name: 'bridge_steel',
    surface: 'metal',
    opts: { vertexMasks: true, tint: 0x4a4640 },
  },
  /**
   * The pre-`steel`-key name, kept as the fallback `bridges.js` uses for a span
   * with no authored colour. Identical to `bridge_gold`, because gold is what
   * every bridge in the city used to be.
   */
  bridge_steel: { name: 'bridge_steel', surface: 'metal', opts: { vertexMasks: true } },
  bridge_rail: { name: 'plate_steel', surface: 'metal', opts: { vertexMasks: true } },
};
