# ONE BBM Android build

The web game is packaged as a native Android application with Capacitor.
The Android app is forced to landscape in the generated `AndroidManifest.xml`.

## Build locally

1. Install Node.js 20+, Java 21, Android Studio and Android SDK.
2. Run `npm install` (the lockfile is refreshed if Capacitor dependencies were added).
3. Run `npm run build`.
4. Run `npx cap add android` once.
5. Run `npx cap sync android`.
6. In `android/app/src/main/AndroidManifest.xml`, set the main activity's `android:screenOrientation` to `landscape`.
7. Run `cd android && ./gradlew assembleDebug`.
8. The debug APK is at `android/app/build/outputs/apk/debug/app-debug.apk`.

## GitHub Actions

The workflow `.github/workflows/android-apk.yml` builds a debug APK when pushed to
`main`/`master`, or when manually started with **Actions → Build ONE BBM Android APK → Run workflow**.
The APK is uploaded as the `ONE-BBM-debug-apk` artifact.

The repository's original world, player and gameplay systems are retained. This
first Android milestone only packages the existing game and locks the display to
landscape; it does not claim multiplayer or device-tested stability.
