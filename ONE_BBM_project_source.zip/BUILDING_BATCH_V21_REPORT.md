# ONE BBM v21 — bounded building construction

## Change

The streamed tile building path previously planned a tile, ran `buildPlan()` for every lot in one scheduler job, and finalized the TileBuilder in that same job. A time-budgeted scheduler cannot preempt a single expensive job, so this could hitch even when the queue's budget was functioning correctly.

The near and far tile paths now accumulate the same plans into one TileBuilder over multiple scheduled jobs:
- near/full-detail: 3 lots per job, priority 0
- far/LOD: 5 lots per job, priority 3
- TileBuilder finalization still happens once, after all lots are emitted.
- Same plan list, `buildPlan` LOD, materials, geometry and collision finalization are retained.
- Live-record checks run before every batch; a tile unloaded while work is queued will stop rather than emit orphaned geometry.
- Existing failed-lot logging remains; finalization failures still use `_buildFailed`.

## Verification

- `node --check src/buildings/index.js`: passed.
- `node tools/syntaxcheck.mjs`: 196 files parse.
- `node tools/lintticks.mjs`: 301 files clean.
- `node src/world/streamingqueueprobe.mjs`: 8 checks passed.
- `tileleakprobe` could not run because Playwright is not installed in this environment; no browser/device run was performed.

## Limits

This bounds work between lots, but one unusually expensive `buildPlan()` call and final `TileBuilder.build()` are still indivisible and can cause a hitch. It does not claim phone thermal, FPS, or APK validation.
