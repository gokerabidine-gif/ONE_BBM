# ONE BBM v22 — lower temporary geometry-conversion memory peak

## Change
`Accum.build()` converts its large JS-number source arrays into BufferGeometry attributes. Previously, all source arrays remained referenced until every attribute and index had been converted, while typed-array copies were already allocated. The method now releases each source array immediately after its corresponding conversion (`pos`, `nrm`, `uv`, `col`, `idx`). This shortens temporary source-array lifetime and lowers peak retained temporary memory during tile finalization, without changing vertex/index contents or geometry topology.

## Verification
- `node tools/syntaxcheck.mjs`: 197 harness files parse.
- `node tools/lintticks.mjs`: 301 files clean.
- Focused `accumreleaseprobe.mjs` was added, but could not execute in this environment because dependencies (Three.js) are not installed (`ERR_MODULE_NOT_FOUND`).
- ZIP integrity checked.

## Limits
This is a memory-lifetime optimization, not a measured phone memory/thermal improvement. Browser/device testing and a production build were not available.
