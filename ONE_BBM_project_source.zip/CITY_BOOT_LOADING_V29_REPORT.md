# ONE BBM v28 — loading responsiveness patch (v29)

## Changes
- World boot progress is published to `window.__WORLD_BOOT_PROGRESS__` so the loader can use terrain/city/lot phases instead of only coarse milestones.
- City-generation worker explicitly reports the start and completion of the synchronous city-plan phase (no fabricated intermediate progress).
- Loader creep time reduced from 26 seconds to 8 seconds, still capped by real milestone/progress targets and `world:ready`.
- UI milestone adjusted from 34% to 28% to leave more headroom for actual world progress.

## Verification
- `node tools/syntaxcheck.mjs`: 198 harness files parse.
- `node tools/lintticks.mjs`: 301 files clean.
- `node src/world/streamingqueueprobe.mjs`: 8 checks passed.
- Async lot subdivision probe passed.
- Async terrain bake probe passed.
- ZIP integrity checked.

## Limitations
- City-plan generation remains a single synchronous function inside a worker; progress reports start/end only.
- No browser/device performance measurements or Android APK build were performed in this environment.
