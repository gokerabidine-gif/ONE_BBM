# ONE BBM v16 — Cooperative lot subdivision

## Baseline recovery
This package is reconstructed from the available `decarlo-boyz-main.zip` library archive. It is not a verified merge of every previously claimed v10-v15 package.

## Actual change
- Added `subdivideAsync()` in `src/world/lots.js`.
- Gameplay `WorldSystem.init()` now awaits it with 24-block batches.
- It preserves block order, RNG draw order, and lot IDs; yields to the event loop between batches, and also yields while constructing the `byTile` index for large lot counts.
- Progress is exposed on `WorldSystem.bootProgress` as `{phase, completed, total, lots}`.
- Synchronous `subdivide()` remains available for deterministic probes/tools.
- Added `npm run subdivideasync` regression probe.

## Verification
- `node tools/syntaxcheck.mjs`: 194 harness files parsed.
- `node tools/lintticks.mjs`: 300 files clean.
- Async equivalence probe: passed; 615 lots generated from 260 synthetic blocks, exact deep equality to sync records and tile-index membership; 16 progress yields.
- ZIP integrity: checked.

## Limitations
- `generateCity()` remains synchronous and can still be the dominant boot stall.
- Progress property is not wired to the loading UI yet.
- Browser runtime, Vite build, Android APK, FPS/thermal/device tests were not run. Dependencies are not installed in this workspace.
