# ONE BBM v20 — World job queue optimization

## Changes
- Replaced per-job `Array.shift()` in the world scheduler with per-priority head cursors. This avoids repeated array element movement for large job queues.
- Buckets compact only when fully drained or when a consumed prefix is large (>256) and at least half the array.
- Preserved ascending priority order (0 is highest), pending counts, jobs enqueued by jobs, and queue clear semantics.
- Deterministic capture mode no longer reads the injected clock at all; its `lastMs` statistic is set to 0 in this mode. Play mode retains the wall-clock budget.

## Verification
- `node src/world/streamingqueueprobe.mjs`: 8 assertions passed.
- `node tools/syntaxcheck.mjs`: 196 harness files parse.
- `node tools/lintticks.mjs`: 301 files clean.
- ZIP integrity verified.

## Limitations
This improves queue bookkeeping overhead, not the duration of a single geometry-building job. Large indivisible building jobs may still cause frame stalls; actual Android performance and APK build are not tested here.
