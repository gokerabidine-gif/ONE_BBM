# ONE BBM v26 — Worker and Android build hardening

## Changes
- City-generation Worker now validates the incoming message envelope before accepting it.
- Worker deserialization failures (`messageerror`) now reject boot with an explicit error instead of leaving the startup promise pending.
- Worker runtime errors call `preventDefault` when available and reject with a useful message.
- Added `android/gradle.properties` enabling AndroidX and setting predictable Gradle JVM options.

## Checks completed
- JavaScript syntax harness: 198 files parsed.
- lintticks: 301 files clean.
- terrainbakeasync probe: 5 checks passed.
- streaming queue probe: 8 checks passed.
- async lot subdivision probe: 3 checks passed.

## Checks not completed
- Vite production build: blocked because Vite is not installed in the extracted `node_modules`; `npm ci --offline` reports the Vite tarball is not cached, and online `npm ci` timed out.
- Android APK: not built. This environment has no Android SDK (`ANDROID_HOME` / `ANDROID_SDK_ROOT`) and no Gradle executable.
- Device/WebView Worker runtime: not tested on a physical Android device.

This archive is source code, not an APK. No claim of device validation is made.
