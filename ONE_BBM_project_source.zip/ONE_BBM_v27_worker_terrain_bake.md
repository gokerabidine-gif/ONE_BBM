# ONE BBM v27 — Move terrain baking into the city worker

## Actual source changes
- On WebViews that support module Workers, the 8 m terrain heightfield is now baked inside `citygen.worker.js` instead of on the UI thread.
- The worker then runs the existing city-generation algorithm and returns the same terrain arrays, road graph, blocks, bridges, and POIs.
- Worker progress now reports the terrain stage to the loading state.
- WebViews without Worker support retain the cooperative `bakeAsync` fallback and the existing synchronous city-plan fallback.
- The city RNG fork is still taken at the same point, preserving the existing deterministic seed stream.

## Scope and limitations
- This is a main-thread responsiveness improvement; it does not reduce city geometry, terrain samples, physics, or visual detail.
- It does not prove the total time-to-city is shorter on every device. Worker scheduling and message transfer must be measured on the target Android WebView.
- APK build and physical-device validation are still required.

## Validation performed in this workspace
- `node tools/syntaxcheck.mjs`: passed (198 harness files parsed).
- `node tools/lintticks.mjs`: passed (301 files clean).
- `node src/world/terrainbakeasyncprobe.mjs`: passed (5 checks).
- `node src/world/streamingqueueprobe.mjs`: passed (8 checks).
- `node src/world/subdivideasyncprobe.mjs`: passed (3 checks; 615 lots / 260 blocks).
- `npm run build`: not completed because Vite is not installed (`vite: not found`).
- Android APK and physical WebView validation: not performed.
