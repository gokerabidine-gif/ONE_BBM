# ONE BBM — Cooperative terrain bake fix

## Actual change
- Added `Terrain.bakeAsync({ rowsPerBatch, onProgress })` with identical sample math, grid writes, and min/max calculation as synchronous `bake()`.
- World boot now awaits the async bake in 12-row batches, yielding between batches so the browser can paint/respond.
- Added `src/world/terrainbakeasyncprobe.mjs` and `npm run terrainbakeasync`.

## Verification
- Probe: 5 checks passed; synchronous/asynchronous grids and min/max matched exactly on a 65x65 test grid; 10 progress batches observed.
- `node --check` on modified files: passed.
- `node tools/syntaxcheck.m`: 195 files parse.
- `node tools/lintticks.m`: 300 files clean.
- ZIP integrity: checked.

## Limits
- This is cooperative main-thread batching, not a worker; each 12-row batch still occupies the main thread briefly.
- `generateCity()` remains synchronous and may still cause a large startup hitch. Worker/off-main-thread city generation is a larger architectural change and is not claimed implemented.
- No Vite build, APK, gameplay runtime, or device FPS/thermal test performed.
