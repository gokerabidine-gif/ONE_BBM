# ONE BBM Android build

The wrapper uses AndroidX `WebViewAssetLoader` with the origin `https://appassets.androidplatform.net/assets/`. Vite **must** be built with `OW_BASE=/assets/`; this makes static assets and module Workers resolve beneath the registered `/assets/` handler (including on-device, without `file://`).

## Build a debug APK

Requirements: Node.js 20+, npm, Android SDK Platform 35, Android Build Tools, JDK 17, and Gradle 8.9+ on PATH.

From the repository root:

```bash
./android/build-apk.sh
```

The script runs `npm ci`, builds the web game with the Android asset base, copies `dist/` into the app assets, then runs `:app:assembleDebug`. Output: `android/app/build/outputs/apk/debug/app-debug.apk`.

Alternatively, run the same steps manually from the root:

```bash
npm ci
OW_BASE=/assets/ npm run build
node tools/package-android-assets.mjs
gradle -p android :app:assembleDebug
```

The repository does not include an Android SDK or a Gradle wrapper JAR. The APK can only be produced on a machine with the prerequisites above. A successful web build alone is not an APK.
