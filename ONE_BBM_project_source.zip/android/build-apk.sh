#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
if [[ -z "${ANDROID_HOME:-}" && -z "${ANDROID_SDK_ROOT:-}" ]]; then
  echo "Android SDK missing: set ANDROID_HOME or ANDROID_SDK_ROOT." >&2
  exit 10
fi
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle missing: install Gradle 8.9+ or open android/ in Android Studio." >&2
  exit 11
fi
npm ci
OW_BASE=/assets/ npm run build
node tools/package-android-assets.mjs
gradle -p android --no-daemon :app:assembleDebug
APK="$ROOT/android/app/build/outputs/apk/debug/app-debug.apk"
test -s "$APK"
echo "APK ready: $APK"
