import { Terrain } from './terrain.js';
import { Rng } from '../core/rng.js';
import { generateCity } from './netgen.js';

self.onmessage = async (event) => {
  const data = event.data;
  try {
    const terrain = new Terrain({ cell: data.cell, extent: data.extent });
    // Bake in small row batches inside the worker. The UI thread stays free,
    // while progress messages can reach the loading UI during the terrain pass.
    // bakeAsync uses the same sample arithmetic as bake(), preserving the field.
    await terrain.bakeAsync({ rowsPerBatch: 16, onProgress: (progress) => {
      self.postMessage({ type: 'progress', stage: 'terrain', progress });
    } });

    self.postMessage({ type: 'progress', stage: 'city-plan', progress: 0 });
    const rng = new Rng(1);
    rng.s0 = data.rng[0]; rng.s1 = data.rng[1]; rng.s2 = data.rng[2]; rng.s3 = data.rng[3];
    const city = generateCity(terrain, rng);
    const graph = { nodes: city.graph.nodes, edges: city.graph.edges };
    self.postMessage({ type: 'progress', stage: 'city-plan', progress: 1 });
    self.postMessage({ ok: true, graph, blocks: city.blocks, bridges: city.bridges, pois: city.pois,
      terrain: { grid: terrain.grid, roadW: terrain.roadW, min: terrain._min, max: terrain._max } },
      [terrain.grid.buffer, terrain.roadW.buffer]);
  } catch (error) {
    self.postMessage({ ok: false, error: error?.stack || String(error) });
  }
};
