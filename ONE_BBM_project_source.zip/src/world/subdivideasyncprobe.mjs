import assert from 'node:assert/strict';
import { subdivide, subdivideAsync, resetLotIds } from './lots.js';
import { Rng } from '../core/rng.js';

const terrain = { waterDist: () => 999, heightAt: (x, z) => Math.sin(x * 0.001) * 0.2 + Math.cos(z * 0.001) * 0.2 };
const blocks = Array.from({ length: 260 }, (_, i) => ({
  cx: (i % 26) * 64 - 800,
  cz: Math.floor(i / 26) * 72 - 360,
  w: 48 + (i % 5) * 9,
  d: 42 + (i % 4) * 11,
  yaw: (i % 7) * 0.11,
  district: ['grid', 'hill', 'mill', 'park', 'campus', 'downtown'][i % 6],
  kind: ['grid', 'hill', 'mill', 'park', 'campus', 'downtown'][i % 6],
}));
const asEntries = (m) => [...m.entries()].map(([k, v]) => [k, v.map((l) => l.id)]).sort(([a], [b]) => a.localeCompare(b));
resetLotIds();
const sync = subdivide(blocks, terrain, new Rng(0x77aabb));
resetLotIds();
let yields = 0;
const asyncResult = await subdivideAsync(blocks, terrain, new Rng(0x77aabb), { batchSize: 17, onProgress: () => yields++ });
assert.deepEqual(asyncResult.lots, sync.lots, 'lot records match synchronous version');
assert.deepEqual(asEntries(asyncResult.byTile), asEntries(sync.byTile), 'tile-index membership matches');
assert.ok(yields >= 15, `expected progress/yields, got ${yields}`);
console.log(`subdivideAsync probe: 3 checks passed; ${sync.lots.length} lots, ${blocks.length} blocks, ${yields} yields`);
