import assert from 'node:assert/strict';
import { Terrain } from './terrain.js';

const sync = new Terrain({ cell: 8, extent: 256 }).bake();
const asyncTerrain = new Terrain({ cell: 8, extent: 256 });
let yields = 0;
await asyncTerrain.bakeAsync({ rowsPerBatch: 7, onProgress: () => yields++ });
assert.equal(asyncTerrain.baked, true);
assert.equal(asyncTerrain.n, sync.n);
assert.deepEqual(asyncTerrain.grid, sync.grid);
assert.equal(asyncTerrain._min, sync._min);
assert.equal(asyncTerrain._max, sync._max);
assert.ok(yields > 1, `expected multiple batches, got ${yields}`);
console.log(`terrain bakeAsync probe: 5 checks passed; ${sync.n}x${sync.n} grid, ${yields} batches`);
