import { cp, mkdir, rm, stat, readFile } from 'node:fs/promises';
import { resolve, relative } from 'node:path';
const root = resolve(import.meta.dirname, '..');
const dist = resolve(root, 'dist');
const assets = resolve(root, 'android/app/src/main/assets');
const index = resolve(dist, 'index.html');
try { await stat(index); }
catch { console.error('Web build missing: run npm run build with OW_BASE=/assets/ first.'); process.exit(1); }
const html = await readFile(index, 'utf8');
if (!html.includes('/assets/')) {
  console.error('Unexpected Vite base path. Build with OW_BASE=/assets/ so appassets URLs resolve through WebViewAssetLoader.');
  process.exit(2);
}
await mkdir(assets, { recursive: true });
await rm(assets, { recursive: true, force: true });
await mkdir(assets, { recursive: true });
await cp(dist, assets, { recursive: true });
const copiedIndex = resolve(assets, 'index.html');
await stat(copiedIndex);
console.log(`Android Web assets copied (${relative(root, assets)}).`);
